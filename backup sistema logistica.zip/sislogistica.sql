-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 04-Jun-2019 às 17:12
-- Versão do servidor: 10.1.34-MariaDB
-- PHP Version: 7.2.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sislogistica`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `empenho`
--

CREATE TABLE `empenho` (
  `id` int(4) NOT NULL,
  `sigla` varchar(50) NOT NULL,
  `seq` int(7) NOT NULL,
  `nd` int(10) NOT NULL,
  `descricao` varchar(500) NOT NULL,
  `finalidade` varchar(500) NOT NULL,
  `qtd` int(20) NOT NULL,
  `vl` decimal(30,0) NOT NULL,
  `vlt` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `empenho`
--

INSERT INTO `empenho` (`id`, `sigla`, `seq`, `nd`, `descricao`, `finalidade`, `qtd`, `vl`, `vlt`) VALUES
(6, '2ª Bda Inf Sl', 79266, 30, ' Cód. UASG: 160428Pregão no 00018/2017 (SISRP)Natureza: 339030Item: 00057 ? Rede Informática - Peça / Acessório, Rede Informática - Peça Manutenção da Rede de Fibra / AcessórioÓptica do Comando da 2a BrigadaDescrição: Protetor de Emenda para Fibra Óptica Tubete 60mm; Pacote com de Infantaria de Selva.300 peças - Marca: GONGFENG; Modelo: 60CM; Protetor de Emenda para fibra Óptica Tubete 60mm composto de uma haste de aço inoxidável; Umtubo plástico interno.', ' Manutenção da Rede de Fibra Óptica do Comando da 2ª Brigada de Infantaria de Selva', 30, '15800', 'R$ 4.199,40'),
(7, '2ª Bda Inf Sl', 79267, 0, ' Cód. UASG: 160152\r\nPregão no 00001/2018 (SISRP)\r\nNatureza: 449052\r\nItem: 00018 ? Rede Informática - Peça / Acessório, Rede Informática - Peça / Acessório\r\nDescrição: Módulo Mini-Gbic Extensão da distância do enlace de fibra em até 10 km; Conector LC para fibras Monomodo. Plug & Play e Hot-Swap,Solução integrada com os switches SG 2404 SR e SG 2622 PR. Alto desempenho com tecnologia Gigabit Ethernet e modo Full.', ' Manutenção da Rede de Fibra / Acessório Óptica do Comando da 2a Brigada de Infantaria de Selva', 30, '13998', 'R$ 4.199,40'),
(8, '2ª Bda Inf Sl', 79269, 0, ' Cód. UASG: 080024\r\nPregão no 00023/2017 (SISRP)\r\nNatureza: 449052\r\nItem: 00019 ? Rede Informática - Peça / Acessório, Rede Informática - Peça / Acessório\r\nDescrição: Cordão óptico duplex, 20 m, com dois conectores tipo lc/pc montados em uma extremidade e dois conectores tipo lc/pc montados na extremidade oposta, monomodo. Suportar comprimento de onda de 1310nm com perda máxima <=0,5db.', ' Manutenção da Rede de Fibra Óptica do Comando da 2º Brigada de Infantaria de Selva', 30, '15969', 'R$ 4.790,70'),
(9, '2ª Bda Inf Sl', 79271, 0, ' Cód. UASG: 154580\r\nPregão no 00010/2017 (SISRP)\r\nNatureza: 449052\r\nItem: 00015 ? Rede Informática - Peça / Acessório, Rede Informática - Peça / Acessório\r\nDescrição: Cordão óptico duplex monomodo 9/125? lc/sc spc 2,5 metros.Cabo composto por duas fibras ópticas monomodo (sm) usando os seguintes conectores: lc- conector do tipo \"push-pull\"- corpo plástico- ferrolho cerâmico- fibra sm- polimento pc (spc/upc) - polimento apc -sc conector dotipo \"push-pull\"', ' Manutenção da Rede de Fibra Óptica da 2º Brigada de Infantaria de Selva', 30, '7111', 'R$ 2.133,30'),
(12, '2ª Bda Inf Sl', 79278, 0, ' Cód. UASG: 987885\r\nPregão no 00012/2018 (SISPP)\r\nNatureza: 449052\r\nItem: 00023 ? Máquina Fusão Fibra Ótica, Máquina Fusão Fibra Ótica\r\nDescrição: Máquina de fusão de fibra óptica, com as seguintes\r\nespecificações: deve possuir display lcd colorido de 5,7?; deve possuir núcleo avançado de sistema de alinhamento de perfil de núcleo de fibra (pas); deve possuir sistema de calibração em tempo real; deve possuir ampliação da exibição dos eixos x e y em no mínimo 304 vezes; deve possuirtempo de fusão', ' Manutenção da Rede de Fibra Óptica do Comando da 2ª Brigada de Infantaria de Selva.', 2, '1323997', 'R$ 26.479,94'),
(14, '2ª Bda Inf Sl', 79294, 0, ' Cód. UASG: 160016\r\nPregão no 00023/2017 (SISRP)\r\nNatureza: 449052\r\nItem: 00001 ? Peça / Acessório - Fibra Óptica, Equipamento / Acessório -\r\nFibra Óptica', ' Descrição: Medidor de potência óptica. Power meter para fibra óptica. \r\nConfiguração mínima: portátil na palma da mão (handheld); calibração \r\ncomprimento de onda de 800 ~ 1700 nm; detector do tipo ingaas; faixas de medição (em dbm): -70 ~ +3, -50 ~ +26; incerteza de +-5%; onda id (nm) de 850m 980, 1300, 1310, 1490 e 155 0; conectores fc intercambiável com sc est).', 1, '85869', 'R$ 858.69'),
(15, '2ª Bda Inf Sl', 79295, 0, 'Cód. UASG: 120630\r\nPregão no 00056/2017 (SISRP)\r\nNatureza: 449052\r\nItem: 00071 ? Peça / Acessório - Fibra Óptica, Equipamento / Acessório Fibra Óptica.\r\nDescrição: Visualizador de Falhas de Fibra Óptica Caneta Óptica; Utilizado para medição em fibras Monomodo ou Multimodo; Tipo de laser: FP-LD;Comprimento de onda (nm): 650 ± 10.', 'Manutenção da Rede de Fibra Óptica do Comando da 2a Brigada\r\nde Infantaria de Selva. ', 5, '31939', 'R$ 1.596,95'),
(16, '2ª Bda Inf Sl', 79256, 0, 'Cód. UASG: 080009\r\nPregão no 00027/2018 (SISRP)\r\nNatureza: 449052\r\nItem: 00001 ? Antena, Tipo: Omnidirecional, Aplicação: Informática, Características\r\nDescrição: Nanostation Antena Integrada de 8dbi; Frequência 2412-2462 MHz (2.4GHz), Processador Atheros 400MHz, Memória 32MB SDRAM, Flash 8MB Potência de Transmissão 23 dBm (200mW), Sensibilidade -75 até -96dBm, Portas LAN 2.\r\n', ' Atender as necessidades de Equipamentos para a Seção de Informática do Comando da 2ª Brigada de Infantaria de Selva.', 10, '10200', 'R$ 1.020,00'),
(17, '2ª Bda Inf Sl', 79257, 0, ' Cód. UASG: 160188\r\nPregão no 00003/2018 (SISRP)\r\nNatureza: 449052\r\nItem: 00029 ? Roteador, Roteador - Interligação Rede Computador\r\nDescrição: Antena Omni 25dbi; Frequência: 5.8 GHz. Polarização: Dupla. Impedância: 50 Ohms. VSWR: <1.5:1. Ganho: 25dBi Irradiação: \r\nOmnidirecional. Abertura. Vertical: 8o.Abertura Horizontal: 360o.\r\nConector: N Fêmea. Cor: Preto.', 'Atender as necessidades de Equipamentos para a Seção de Informática do Comando da 2ª Brigada de Infantaria de Selva.', 10, '30899', 'R$ 3.089,90'),
(20, '2ª Bda Inf Sl', 79259, 0, ' Cód. UASG: 120638\r\nPregão no 00017/2018 (SISRP) Natureza: 449052\r\nItem: 00096 ? Capa, Capa\r\nDescrição: Case Externo HD 3.5 USB 3.0; Interface: Sata. Interface.\r\nExterna: Usb 3.0 / Taxa de Transferência: 5gbps.', 'Atender as necessidades de Equipamentos para a Seção de informática do Comando da 2ª Brigada de Infantaria de Selva.', 8, '10199', 'R$ 815.92'),
(21, '2ª Bda Inf Sl', 79261, 0, 'Cód. UASG: 200352\r\nPregão no 00008/2017 (SISRP)\r\nNatureza: 449052\r\nItem: 00024 ? Disco Rígido Removível, Disco Rígido Removível\r\nDescrição: HD Externo capacidade mínima 5TB; Interface USB 3.0;\r\nFonte de alimentação externa.', 'Atender as necessidades de Equipamentos para a Seção de Informática do Comando da 2ª Brigada de Infantaria de Selva.', 5, '90175', 'R$ 4.508,75'),
(24, '2ª Bda Inf Sl', 79262, 0, 'Cód. UASG: 154810\r\nPregão no 00002/2017 (SISRP)\r\nNatureza: 449052\r\nItem: 00002 ? Switch, 48 Un, Gigabit Ethernet 1000 Base Sx, 10/100 E 1000 Mbps, 110/220 Vca, 60 Hz, Fibra Óptica Multimodo E Conectores Lc\r\nDescrição: Switch Portas: 48 portas 10/100/1000 RJ-45 com egociação automática; 4 portas SFP 1000 Mbps; Suporta um máximo de 48 portas10/100/1000 com detecção automática e mais 4 portas SFP\r\n1000BASE-X, ou uma combinação.', 'Atender as necessidades de Equipamentos para a Seção de de Informática do Comando da 2ª Brigada de Infantaria de Selva.', 15, '200000', 'R$ 30.000,00'),
(25, '2ª Bda Inf Sl', 79265, 0, 'Cód. UASG: 154039\r\nPregão no 00356/2017 (SISRP)\r\nNatureza: 339030\r\nItem: 00023 ? Fonte Alimentação, 500 w, 50/60 hz, 5,Padrão atx, 110 / 220 vcaDescrição: Fonte de Alimentação ATX 500w, Frequência 50/60 hz, Padrão ATX, Tensão Alimentação ', 'Atender as necessidades de Equipamentos para a Seção de Informática do Comando da 2ª Brigada de Infantaria de Selva. ', 100, '9910', 'R$ 9.910,00'),
(26, '2ª Bda Inf Sl', 79270, 0, 'Cód. UASG: 158155Pregão no 00029/2017 (SISRP)Natureza: 449052Item: 00117 ? Peças / Acessórios Equipamentos Especializados, Peças /Acessórios Equipamentos EspecialDescrição: Pen Drive Capacidade de armazenamento 16 GB; Conexão USB 3.0. ', 'Atender as necessidades de Equipamentos para a Seção de Informática do Comando da 2ª Brigada de Infantaria de Selva.', 20, '230', 'R$ 527.20'),
(27, '2ª Bda Inf Sl', 79272, 0, 'Cód. UASG: 160433\r\nPregão no 00001/2018 (SISRP)\r\nNatureza: 339030\r\nItem: 00030 ? Canaleta, Material: Pvc - Cloreto De Polivinila Características Adicionais: Com Divisória, Dimensões:20 X 10 X 2000\r\nMm, Uso: Sistema \"X\"\r\nDescrição: Canaleta de Pvc 20x10x2000; Largura: 20mm; Altura: 10mm; Comprimento: 2000mm (2 metros).', 'Atender as necessidades de Equipamentos para a Seção de Informática do Comando da 2ª Brigada de Infantaria de Selva.', 60, '230', 'R$ 136.00'),
(28, '2ª Bda Inf Sl', 79273, 0, ' Cód. UASG: 925866\r\nPregão no 00067/2017 (SISPP)\r\nNatureza: 339030\r\nItem: 00034 ? Conector Cabo Par Trançado, Tipo: Macho, Modelo: RJ45, Categoria: 5E\r\nDescrição: Conector Cabo Par Trançado, Tipo Macho, Modelo RJ45, \r\nCategoria 5E.', 'Atender as necessidades de Equipamentos de Informática  para a Seção  de informática do Comando da 2ªde Brigada de Infantaria de Selva.', 1000, '47', 'R$ 470.00'),
(29, '2ª Bda Inf Sl', 79276, 0, 'Cód. UASG: 120630\r\nPregão no 00056/2017 (SISRP)\r\nNatureza: 449052\r\nItem: 00043 ? Memória Ram, Memória Principal\r\nDescrição: Memória RAM DDR3 4GB; Capacidade 4GB; Frequência \r\n1333 ou 1600 MHz, Tipo DDR3 para uso em Desktop. ', 'Atender as necessidades de Equipamentos para a Seção de Informática do Comando da 2aBrigada de Infantaria de Selva. ', 30, '19766', 'R$ 5.929,80'),
(30, '2ª Bda Inf Sl', 79277, 0, 'Cód. UASG: 160086\r\nPregão no 00006/2018 (SISRP)\r\nNatureza: 449052\r\nItem: 00003 ? Disco Rígido Removível, Disco Rígido Removível \r\nDescrição: Disco Rígido interno; Capacidade de 1 TB, SATA, 7200 rpm, , 3,5\".', 'Atender as necessidades de Equipamentos para a Seção de Informática do Comando da 2ª Brigada de Infantaria de Selva.', 25, '28500', 'R$ 7.125,00'),
(31, '2ª Bda Inf Sl', 79279, 0, 'Cód. UASG: 158335\r\nPregão no 00009/2017 (SISRP)\r\nNatureza: 449052\r\nItem: 00009 ? Processador, Processador\r\nDescrição: Processador Intel Core i7 LGA 1151; Processador Marca: Intel; Soquete: LGA 1151; Litografia: 14 nm; Núcleos: 4; Threads: 8; Frequência 4.20 GHz; Frequência Turbo: 4.50 GHz; Cache: 8 MB. ', ' Atender as necessidades de Equipamentos para a Seção de Informática do Comando da 2ª Brigada de Infantaria de Selva.', 15, '135400', 'R$ 203.100,0'),
(32, '2ª Bda Inf Sl', 79285, 30, 'Cód. UASG: 160165Pregão no 00013/2017 (SISRP)Natureza: 449052Item: 00043 ? Placa Mãe, Placa MãeDescrição: Placa Mãe DDR3 LGA 1151; Placa Mãe Suporta 6a e 7a Geração de processadores Intel Core/Intel Pentium/Intel Celeron no pacote Brigada de Infantaria de Selva.LGA 1151; Memória: 2 x DDR3 DIMM sockets suportam até 32 GB dememória; Padrão ATX.', 'Atender as necessidades de Equipamentos para a seção de Informática do Comando da 2ª Brigada de Infantaria de Selva', 20, '49899', 'R$ 9.979,80'),
(33, '2ª Bda Inf Sl', 79287, 30, 'Cód. UASG: 160428Pregão no 00018/2017 (SISRP)Natureza: 339030Item: 00072 ? Rede Informática - Peça / Acessório, Rede Informática - Peça / AcessórioDescrição: Pasta Térmica 100g ou mais, para processadores, transistor potência, circuitos integrados CIs, Cooler; Características: Pastosa; corbranca brilhante, temp. trabalho: -40 a 200 °C, componente básico: ', 'Atender as necessidades Equipamentos para a Seção Informática do Comando da 2ª Brigada de Infantaria de Selva.', 10, '1673', 'R$ 167.30'),
(34, '2ª Bda Inf Sl', 79290, 0, 'Cód. UASG: 154419\r\nPregão no 00039/2017 (SISPP)\r\nNatureza: 449052\r\nItem: 00015 ? Leitora Dvd, Leitora De Fita Magnética\r\nDescrição: Leitor/Gravador Dvd/Cd Slim Portátil - Alimentação e dados \r\npor USB. Compatível com Windows 7, 8 e 10. ', 'Atender as necessidades de Equipamentos para a Seção de Informática do Comando da 2ª Brigada de Infantaria de Selva.', 5, '14964', 'R$ 748.20'),
(35, '2ª Bda Inf Sl', 79292, 0, ' Cód. UASG: 160344\r\nPregão no 00002/2018 (SISRP)\r\nNatureza: 449052\r\nItem: 00063 ? Placa Rede, Placa Para Rede De Comunicação De Dados\r\nDescrição: Placa de Rede Pci-E 10/100/1000; Conectores 1 x RJ45; Brigada de Infantaria de Selva.\r\nInterface PCI-Express 1.0a; Tipo de interface de sistema PCIe v1.1\r\n(2.5GT/s) Velocidade e Largura de Slot 2.5 GT/s.', 'Atender as necessidades de Equipamentos para a Seção de informática do Comando da 2ª Brigada de Infantaria de Selva.', 20, '2999', 'R$ 599.80'),
(36, '2ª Bda Inf Sl', 79293, 0, 'Cód. UASG: 989979\r\nPregão no 00037/2018 (SISRP)\r\nNatureza: 449052\r\nItem: 00085 ? Rede Informática - Peça / Acessório,\r\nRede Informática - Peça / Acessório\r\nDescrição: Placa De Rede Pci Wireless 802.11a/b/g/n; Padrão N; Modo de operação: AD HOC / Infraestrutura; Protocolo: 802.11a/b/g/n (Draft 2.0); Conexão Canais13- Alcance: 300 metros; Frequência: 24Ghz- Segurança: WPA/WPA2; Adaptador Wireless PCI: 150 Mbps. ', 'Atender as necessidades de Equipamentos para a Seção de Informática do Comando da 2ª Brigada de Infantaria de Selva.', 20, '3711', 'R$ 742.20'),
(37, '2ª Bda Inf Sl', 79297, 0, 'Cód. UASG: 158319\r\nPregão no 00012/2017 (SISRP)\r\nNatureza: 449052\r\nItem: 00095 ? Placa Controladora Vídeo, Placa Controladora Vídeo\r\nDescrição: Placa de Vídeo no mínimo 1GB de capacidade de memória;\r\nInterface PCI express 3.0; chipset; GPU GTX 750Ti; clock do core\r\n1020MHz - Memória 5400MHz 2GB interface 128 bits tipo GDDR5; API\r\n3D; Portas 1 x HDMI, 1 x DisplayPort, 1 x DVI-I, 1 x VGA. ', 'Atender as necessidades de Equipamentos para a Seção de  Informática do Comando da 2ª Brigada de Infantaria de Selva.', 20, '23128', 'R$ 4.625,60'),
(38, '2ª Bda Inf Sl', 79300, 0, 'Cód. UASG: 250019\r\nPregão no 00004/2017 (SISRP)\r\nNatureza: 449052\r\nItem: 00042 ? Tomada Duplicadora Ponto, Modelo: Rj45, Tipo: \"Y\", \r\nAplicação: Comunicação De Dados\r\nDescrição: Duplicador de Cabo de Rede Rj45 1 fêmea X 2 fêmea; \r\nAdaptador ?Y? com 3 interfaces RJ-45 fêmea, 8 pinos, fiação paralela, \r\nCAT5/CAT6; Permite converter um ponto de rede RJ-45 em dois pontos de rede RJ-45. ', 'Atender as necessidades de Equipamentos para a Seção de Informática do Comando da 2ª Brigada de Infantaria de Selva.', 40, '1099', 'R$ 439.60'),
(40, '2ª Bda Inf Sl', 79258, 0, 'Cód. UASG: 160019\r\nPregão no 00016/2017 (SISRP)\r\nNatureza: 339030\r\nItem: 00033 ? Cabo Rede Computador, Pvc - Cloreto De Polivinila, Cobre Rígido, 24 Awg, Par Trançado Não Blindado, Utp De 4 Pares, Suporta Freqüências De Até 2.500 Mhz, Norma Eia/, 5e, Inferior A 1 M, Polietileno De Alta Densidade\r\nDescrição: Cabo de Rede para Computador, Material Revestimento Pvc, Tipo Condutor Par Trançado Não Blindado, Tipo Cabo Utp De 4 Pares,\r\nCaracterísticas Adicionais Suporta Freqüências Até 500 Mhz, Norma ', 'Atender as necessidades de Equipamentos de Informática do Comando da 2ª Brigada de\r\nBrigada de Infantaria de Selva.', 5, '19545', 'R$ 977.25'),
(41, '2ª Bda Inf Sl', 79260, 0, ' Cód. UASG: 160228\r\nPregão no 00015/2017 (SISRP)\r\nNatureza: 449052\r\nItem: 00026 ? Rede Informática - Peça / Acessório, Rede\r\nInformática - Peça / Acessório\r\nDescrição: Nobreak Potência: 1800VA Frequência: 60Hz; Bivolt \r\nautomático: entrada 115/127V~ ou 220V~ e saída 115V~; 07 Tomadas padrão NBR 14136; Extensão com mais 4 tomadas; Filtro de linha; Estabilizador interno com 4 estágios Regulação.', ' Atender as necessidades de Equipamentos de Informática do Comando da 2ª Brigada de Infantaria de Selva.', 30, '75000', 'R$ 22.500,00'),
(42, '2ª Bda Inf Sl', 79264, 0, 'Cód. UASG: 158139\r\nPregão no 00098/2017 (SISPP)\r\nNatureza: 449052\r\nItem: 00006 ? Estabilizador Tensão, Estabilizador Tensão\r\nDescrição: Estabilizador 1kva; Faixa de tensão de entrada: 92V a 258V (Full range). Corrente nominal de entrada: 4,3 para 115V; 3,9 para 127V; 2,3 para\r\n220V. Tempo de resposta <= 1; Dimensões AxLxP (mm): 192; Estabilizador 1kva 6 tomadas 115v - Estabilizador Microprocessado. - Função True rms. -Porta Fusível. - Atende à norma brasileira para estabilizadores de tensão nbr1', ' Atender as necessidades de Equipamentos de Informática do Comando da 2a Brigada de Infantaria de Selva.', 40, '15507', 'R$ 6.202,80'),
(43, '2ª Bda Inf Sl', 79274, 0, 'Cód. UASG: 154039\r\nPregão no 00356/2017 (SISRP)\r\nNatureza: 449052\r\nItem: 00013 ? Teclado Microcomputador, Abnt2, Convencional, Usb, Compatível Com Windows, Linux\r\nDescrição: Teclado Microcomputador USB Apoio destacável, Plug & Play, Padrão ABNT2, Formato Convencional, compatível com Windows e Linux.', ' Atender as necessidades dede Equipamentos de Informática do Comando da 2a Brigada de Infantaria de Selva.', 50, '1550', 'R$ 775.00'),
(44, '2ª Bda Inf Sl', 79275, 0, 'Cód. UASG: 160022Pregão no 00002/2018 (SISRP)Natureza: 449052Item: 00066 ? ', ' Atender as necessidades de Equipamentos de Informática do Comando da 2a Brigada de Infantaria de Selva.', 50, '800', 'R$ 400'),
(45, '2ª Bda Inf Sl', 79286, 0, 'Cód. UASG: 160477\r\nPregão no 00026/2017 (SISRP)\r\nNatureza: 449039\r\nItem: 00027 ? Software, Software\r\nDescrição: Sistema Operacional Microsoft Windows 7 Professional 32/64 Bits, Conteúdo adquirido: Cartão COA Licença COEM (serial 25 dígitos) \r\nWindows Professional 64 Bits FQC-08286, Box c/ 2 Mídias Recovery 32 e 64 Bits; Idioma Português. ', ' Atender as necessidades deEquipamentos de Informática doComando da 2a Brigada deInfantaria de Selva.', 30, '27030', 'R$ 8.109,00'),
(46, '2ª Bda Inf Sl', 79288, 0, 'Cód. UASG: 925136\r\nPregão no 00003/2017 (SISPP)\r\nNatureza: 449052\r\nItem: 00334 ? Cabo Extensor, Tipo Saída: Conectores Hd15 Macho X\r\nMacho, Comprimento:20 M, Aplicação: Multimídia, Características\r\nAdicionais: Filtro De Ferrite Nas Duas Pontas Para Reduzir Int, Padrão:\r\nVga/Svga/Rgb, Material: Cobre, Tratamento Superficial: Borracha\r\nDescrição: Cabo VGA com dupla blindagem e filtro de 20 metros com saída Db15 Macho x Db15 Fêmea, compatível com as resoluções VGA 640 x 350, SVGA 800 x 600, SXVGA 1', ' Atender as necessidades deEquipamentos de Informática do Comando da 2ª Brigada deInfantaria de Selva.', 10, '9179', 'R$ 917.90'),
(47, '2ª Bda Inf Sl', 79289, 0, ' Cód. UASG: 238014\r\nPregão no 00560/2018 (SISPP)\r\nNatureza: 449052\r\nItem: 00012 ? Tablet, Tablet\r\nDescrição: Tablet Samsung Galaxy Tab A 3G 4G 16GB LCD 8? Android \r\n5.0 (Lollipop); Tipo de Tela: LCD; Tamanho da Tela: 8\"; Resolução Tela: HD; Sistema Operacional: Android 5.0 (Lollipop); Memória Ram: 2 GB; Núcleo do Processador: Quad Core 1,2', ' Atender as necessidades deEquipamentos de Informática doComando da 2a Brigada deInfantaria de Selva.', 25, '110275', 'R$ 27.568,75'),
(48, '2ª Bda Inf Sl', 79291, 0, 'Cód. UASG: 120633\r\nPregão no 00050/2017 (SISRP)\r\nNatureza: 449039\r\n\r\nItem: 00094 ? Software, Windows, MS Office 2013\r\n\r\nProfessional, Open Educacional\r\nDescrição: Pacote Microsoft Office 2013 Professional 32/64 bits - Licença \r\nde uso perpétuo do pacote Microsoft Office 2013, Standard, ou versão \r\nsuperior com downgrade para versão 2013, completo, no idioma Português\r\n(Brasil), para sistema operacional Microsoft Windows. ', ' Atender as necessidades deEquipamentos de Informática doComando da 2a Brigada deInfantaria de Selva.', 30, '30000', 'R$ 9.000,00'),
(51, '2ª Bda Inf Sl', 79299, 0, ' Cód. UASG: 160147\r\nPregão no 00001/2018 (SISRP)\r\nNatureza: 449052\r\nItem: 00154 ? Cadeira Escritório, Cadeira EscritórioDescrição: Cadeira Secretária Giratória Escritório - Assento e Encosto \r\nestofado em espuma Laminada; Cor Preta; Capacidade de Peso de até 110 kg; Cor Preta, com regulagem de altura, base giratória.', ' Atender as necessidades de Equipamentos de Informática do Comando da 2ª Brigada de Infantaria de Selva.', 40, '19640', 'R$ 7.856,00'),
(52, '2ª Bda Inf Sl', 79301, 0, 'Cód. UASG: 158442\r\nPregão no 00055/2017 (SISRP)\r\nNatureza: 339030\r\nItem: 00011 ? Tomada, Tomada\r\nDescrição: Tomada Rj45 (Cat. 6) - Peso Líquido: 0,0250 kg; Peso Bruto: 0,0250 kg; Metragem: 0,000032 m3; Dimensões Produto (Compr. X Larg. X Alt.): 40x 40 mm; Cor Branca. ', ' Atender as necessidades de Equipamentos de Informática do Comando da 2ª Brigada deInfantaria de Selva.', 60, '1378', 'R$ 826.80'),
(53, '2ª Bda Inf Sl', 79302, 0, 'Cód. UASG: 158743\r\nPregão no 00020/2018 (SISRP)\r\nNatureza: 449052\r\nItem: 00133 ? Peça / Acessório Iluminação, Material\r\nIluminação - Estadio\r\nDescrição: Módulo Tomada Rj45 (Cat. 6) - Peso 0,03 kg; Comprimento 45 mm; Largura 22 mm; Altura 33 mm; Cor Branca. ', ' Atender as necessidades de Equipamentos de Informática do Comando da 2ª Brigada de Infantaria de Selva.', 60, '1167', 'R$ 700.20'),
(54, '2ª Bda Inf Sl', 79303, 0, 'Cód. UASG: 160466\r\nPregão no 00013/2018 (SISRP)\r\nNatureza: 339030\r\n\r\nItem: 00058 ? Impressora Laser, Impressora ? Laser\r\n\r\nDescrição: Toner Samsung MLT-D111L D111L | Xpress M2020 M2020FW M2070 M2070W M2070FW, original 1.8k - Cartucho de Toner Samsung MLTD111S MLTD111. Cor: Preto/Black Original. Indicado para uso nas seguintes impressoras: Xpress SL-M2020W M-2020 M-2020F. ', ' Atender as necessidades de Equipamentos de Informática do Comando da 2a Brigada de Infantaria de Selva.', 50, '6250', 'R$ 3.125,00'),
(55, '2ª Bda Inf Sl', 79304, 0, ' Cód. UASG: 153035\r\nPregão no 00084/2017 (SISRP)\r\nNatureza: 339030\r\n\r\nItem: 00082 ? Peça / Acessório - Impressora / Copiadora,\r\n\r\nPeca / Acessório - Impressora\r\nDescrição: Kit 4 Tintas para Epson T664 Black 1 Litro Color 500ml Corante  Koga - Tinta Epson L495; Modelo de Referência: T664; Tinta Corante; 4 Biocos Aplicadores; Conteúdo: Black (Preto) 1 Litro | Coloridas 500ml; Cor:\r\nCyan (Azul), Magenta e Yellow (Amarelo)', ' Atender as necessidades deEquipamentos de Informática doComando da 2a Brigada de Infantaria de Selva.', 50, '11960', 'R$ 5.980,00'),
(56, '1º B Com Sl ', 74916, 0, ' Cód. UASG: 160105\r\nPregão nº 03/2018(SRP)\r\nItem: 34 ?NOBREAK\r\nPregão Válido até 11 julho 2019\r\nDescrição: Nobreak 5 kva microprocessado (dsp) online dupla conversão inversor com operações em alta frequência senoidal estabilizado. De qualidade equivalente ou superior ao modelo de referência: nobreak marca cm, modelo solution s1 5000 potência 5kva microprocessado (dsp) dupla conversão, 220 v, monofásico.\r\n', '\r\n\r\n\r\n\r\nInterligação da Rede e Servidores do 1º Batalhão de Comunicações de Selva.\r\nPara revitalização do parque computacional do 1º Batalhão de  Comunicações de  Selva.\r\n ', 3, '430000', 'R$ 12.900,00'),
(57, '16ª Bda Inf SI', 78478, 0, ' Cód. UASG: 160537\r\nPregão nº 0019/2017(SRP)\r\nItem: 51 ? NOBREAK\r\nPregão Válido até 21 outubro 2019\r\n\r\nDescrição: NOBREAK CARACTERÍSTICAS: POTÊNCIA: 3 KVA / 2.7 KW\r\nTECNOLOGIA ON-LINE DUPLA CONVERSÃO (ALIMENTAÇÃO ININTERRUPTA 7 X 24). ALTO FATOR DE POTÊNCIA DE ENTRADA (F.P.>0,99) E BAIXA DISTORÇÃO HARMÔNICA (ITHD<5%). DISPLAY EM LCD OU LED; ENTRADA: 110/220 V. SAÍDA 110V; BAIXOS ÍNDICES DE DISTORÇÃO HARMÔNICA DE ENTRADA E SAÍDA; CHAVE BY-PASS, CONFIGURAÇAO EM RACK 19?, CHAVE ESTÁTICA, PARTIDA EM', 'AUXILIO PARA O NÃO DESLIGAMENTO EQUIPAMENTOS DAS ESTAÇÕES DE TRABALHO DO COMANDO DA 16º BRIGADA DE INFANTARIA DE SELVA ', 30, '46100', 'R$ 13.830,00'),
(59, '16ª Bda Inf SI', 78498, 0, 'Cód. UASG: 160537\r\nPregão nº 0019/2017(SRP)\r\nItem: 21 ? FONTE DE ALIMENTAÇÃO\r\nPregão Válido até 21 outubro 2019\r\n\r\nDescrição: FONTE COMPATÍVEL COM O PADRÃO INTEL ATX 12V V 2.31, TRILHO ÚNICO +12 V PARA AS MAIS EXIGENTES CONFIGURAÇÕES SLI, ALTA EFICIÊNCIA QUE ATENDE ÀS EXIGÊNCIAS PLUS 80 (85% TÍPICO), OPERAÇÃO ULTRA-SILENCIOSA COM CONTROLE DE VELOCIDADE DE FAN INTELIGENTE DE 120MM; PROJETO COM MÚLTIPLAS PROTEÇÕES (OVP / UVP / OPP / OTP / SCP), ALTA CONFIABILIDADE (MTBF> 1000.000 HORAS); CAMADA DU', 'QUIPAMENTO DESTINADO PARA MANUTENIR FONTES QUEIMADAS DAS ESTAÇÕES DE TRABALHO DA 16ª BRIGADA DE INFANTARIA DE SELVA ', 40, '10549', 'R$ 4.219,00'),
(60, '16ª Bda Inf SI', 78456, 0, ' Cód. UASG: 160537\r\nPregão nº 0019/2017(SRP)\r\nItem: 21 ? FONTE DE ALIMENTAÇÃO\r\nPregão Válido até 21 outubro 2019\r\nDescrição: SOFTWARE LICENÇA WINDOWS 10 / 32/64 BITS.', 'SOFTWARE PAGO PARA AS NOVAS ESTAÇÕES DE TRABALHO DA 16ª BRIGADA DE INFANTARIA DE SELVA ', 8, '57474', 'R$ 4.597,92'),
(61, '2ª Bda Inf Sl', 79296, 0, ' Cód. UASG: 160250\r\nPregão no 00010/2017 (SISRP)\r\nNatureza: 449039\r\nItem: 00101 ? Software Aplicativo, Software Aplicativo\r\nDescrição: Licença para Sistema Operacional Microsoft Windows 10 Pro 32/64 Bits.', 'Atender as necessidades de Equipamentos de Informática do Comando da 2a Brigada de Infantaria de Selva.', 20, '27600', 'R$ 5.520,00'),
(62, '2ª Bda Inf Sl', 79298, 0, ' Cód. UASG: 120643\r\nPregão no 00019/2018 (SISRP)\r\nNatureza: 449052\r\n\r\nItem: 00034 ? Cabo Extensor, Tipo Saída: Macho/Macho, Comprimento: \r\n1,80 M, Aplicação: Monitor De Vídeo, Características Adicionais: Sinal Vga \r\nE Svga, Tipo Cabo: Hd-15\r\n\r\nDescrição: Cabo VGA; Comprimento de 1,8 mts, HD15 macho x HD15 macho. Dois filtros antirruídos; Aplicação Monitor de Vídeo.', ' Atender as necessidades de Equipamentos de Informática do Comando da 2a Brigada de Infantaria de Selva.', 30, '19640', 'R$ 7.856,00'),
(63, 'Cia C CMA', 74433, 0, 'Cód. UASG: 160016\r\nPregão no 23/2017 (SRP)\r\nItem: 39 ? NOBREAK\r\nPregão Válido até 4 junho 2018\r\nDescrição: Acumulador tensão NOBREAK para computadores e periféricos.\r\nConfiguração mínima: Topologia: Line interactive; CAPACIDADE de energia de saída: 504 W/1200 VA; Tensão entrada bivolt automático/saída: 127 V, 4 tomadas ', 'Interligar os equipamentos das estações de trabalho\r\nda Cia C CMA ', 13, '32498', 'R$ 4.224,74'),
(64, 'Cia C CMA', 74455, 0, ' Cód. UASG: 160234\r\nPregão no 7/2018 (SRP)\r\nItem: 39 ? Estabilizador\r\nPregão Válido até 31 janeiro 2020\r\nDescrição: Estabilizador tensão, Nobreak 1200 VA - tensão: bivolt\r\nautomático de entrada com saída 115/v/127v. com filtro de linha integrado: contra distúrbios de tensão. minimo de 04 tomadas de saída. proteção contra descarga total das baterias, oscilações da rede elet rica; sobretensão; curto- circuito; surtos de tensão; sobrecarga; sobrecorrente . com autostarter. tempo de resposta máximo:', 'Interligar os equipamentos das estações de trabalho\r\nda Cia C CMA ', 5, '51699', 'R$ 2.584,95'),
(65, 'CMA', 74446, 0, 'Cód. UASG: 160234\r\nPregão no 27/2018 (SRP)\r\nItem: 35 - Teclado Pregão Válido até 31 janeiro 2020\r\nDescrição: Teclado computador, tipo padrão, tipo conector usb, conectividade com fio ', 'Material a ser utilizado nos computadores da Cia C CMA ', 11, '3373', 'R$ 371.03'),
(66, 'Cia C CMA', 74459, 0, 'Cód. UASG: 160234\r\nPregão no 27/2018 (SRP)\r\nItem: 33 ? Mouse\r\nPregão Válido até 31 janeiro 2020\r\nDescrição: MOUSE, tipo usb, modelo óptico, aplicação computador,características adicionais com scroll, quantidade de botões controle 3\r\nunidades, resolução 800 dpi. ', 'Material a ser utilizado nos computadores da Cia C CMA ', 14, '3683', 'R$ 515.62'),
(67, 'Cia C CMA', 74441, 0, ' Cód. UASG: 160346\r\nPregão no 12/2018 (SRP)\r\nItem: 72 ? Monitor\r\nPregão Válido até 12 dezembro 2019\r\nDescrição: Monitor vídeo de no mínimo 21 (vinte e uma) polegadas\r\nwidescreen led colorido plug and play no formato 16:9 devera ter duas\r\nentradas de conexão de vídeo 01 (uma) entrada de vídeo padrão vga; 01 (uma)\r\nentrada de vídeo padrão dvi com se us respectivos cabos sem emendas.', ' Material a ser utilizado nos computadores\r\nda Cia C CMA', 5, '60200', 'R$ 3.010,00'),
(68, 'Cia C CMA', 74467, 0, 'Cód. UASG: 158304\r\nPregão no 29/2018 (SRP)\r\nItem: 40 ? Disco Rígido\r\nPregão Válido até 7 novembro 2019\r\nDescrição: Disco rígido removível, capacidade memória:3 tb, interface: usb 3.0, características adicionais: externo ', 'Material a ser utilizado nas seções da Cia C CMA ', 8, '97099', 'R$ 7.767,92'),
(69, '12ª RM', 77765, 52, 'Cód. UASG: 160486Pregão no 05/2018 (SRP)Item: 3 ? SISTEMA ARMAZENAMENTO AUTOMATICOPregão Válido até 21 novembro 2019Descrição: Sistema de armazenamento (Storage) externo baseado em dispositivos NAS (Network Attached Storage); Deverá ser própriopara instalação em rack padrão 19? ; Deverá ser fornecido com todos os materiais e softwares necessários ao seu funcionamento edesempenho das funcionalidades, incluindo, mas não se limitando, a todos os cabos para conexão dos diversos componentes', 'Recuperação dos ativos de Rede dos Racks do Comando da 12a Região Militar ', 1, '6619500', 'R$ 66.195,00'),
(70, '12º B Sup', 89237, 52, 'Cód. UASG: 160353 - CMAPregão no 12/2018 (SRP)Item: 57 ? REDE INFORMÁTICA ? PEÇA/ACESSÓRIOPregão Válido até 06 / 12 / 2019Descrição: DISCO RÍGIDO 3,5 1TB DISCO RÍGIDO (HARD DISK) SATA 3,5 POLEGADAS, PARA DESKTOP, COM CAPACIDADE DE ARMAZENAMENTO DE 1TB, CACHE 64MB, 7200RPM, 6.0GB/S. EXEMPLO QUE ATENDE: SEAGATE ST1000DM003. ', 'Para uso de Backup dos sistemas da OM. ', 5, '29839', 'R$ 1.491,95'),
(71, '12º B Sup', 89239, 30, 'Cód. UASG: 160353 - CMAPregão no 12/2018 (SRP)Item: 70 ? REDE INFORMÁTICA ? PEÇA/ACESSÓRIOPregão Válido até 06 / 12 / 2019Descrição: PLACA DE VÍDEO VGA 4GB PLACA DE VÍDEO VGA, 4GB DE RAM, GDDR5 128-BIT, PCI EXPRESS 3.0. GPU GEFORCE GTX 1050 TI, CORE CLOCK DE 1290MHZ. CLOCK DE MEMÓRIA: 7010MHZ. RESOLUÇÃO MÁXIMA DE 7680 X 4320. API 3D:DIRECTX 12 E OPENGL 4.5. CONEXÕES: 1X HDMI, 1X DUAL-LINK DVI-D E 1X DISPLAYPORT 1.4. GARANTIA DE 12 MESES. EXEMPLO QUE ATENDE: EVGA 04G-P4-6251-KR. ', 'Para uso no desenvolvimentográfico de mídia na Seção deComunicação Social. ', 2, '93700', 'R$ 1.874,00'),
(72, '12º B Sup', 89246, 30, ' Cód. UASG: 160353 - CMAPregão no 12/2018 (SRP)Item: 63 ? REDE INFORMÁTICA ? PEÇA/ACESSÓRIOPregão Válido até 06 / 12 / 2019Descrição: MEMÓRIA RAM DDR3 8GB (DESKTOP) MEMÓRIA RAM 8GB 1600MHZ DDR3PARA DESKTOP. TIPO: 240-PINOS. EXEMPLO QUE ATENDE: KINGSTON KVR16N11/8.', 'Para Upgrade nos Microcomputadores da OM. ', 10, '28806', 'R$ 2.880,60'),
(73, '12º B Sup', 89248, 30, ' Cód. UASG: 160353 - CMAPregão no 12/2018 (SRP)Item: 36 ? REDE INFORMÁTICA ? PEÇA/ACESSÓRIOPregão Válido até 06 / 12 / 2019Descrição: FONTE ATX 400W FONTE ATX COM AS SEGUINTES ESPECIFICAÇÕES: TIPO:ATX 12V V2.31 E EPS 2.92; POTÊNCIA: 400W; BARRAMENTO: TRILHO ÚNICO DE +12V;TENSÃO DE ENTRADA: 100 - 240V (AUTOMÁTICO); CORRENTE DE ENTRADA: 6.0 -3.0A; FREQUÊNCIA: 47HZ - 63HZ; CERTIFICAÇÃO: 80 PLUS WHITE; EFICIÊNCIA: 80%TÍPICA; VENTOINHA: 1 X 120MM; APROVAÇÕES DE SEGURANÇA: FCC, CE, TÜV', 'Para reposição de fontesqueimadas nosMicrocomputadores emmanutenção na OM. ', 5, '27495', 'R$ 1.374,75'),
(74, '12º B Sup', 89250, 30, 'Cód. UASG: 160353 - CMAPregão no 12/2018 (SRP)Item: 75 ? REDE INFORMÁTICA ? PEÇA/ACESSÓRIOPregão Válido até 06 / 12 / 2019Descrição: PROCESSADOR CORE I5 LGA 1151 PROCESSADOR INTEL CORE I5-7400, 7aGERAÇÃO, LGA 1151, COM 6MB DE CACHE, FREQUÊNCIA DE OPERAÇÃO DE 3.0GHZ,CHIP GRÁFICO INTEL HD GRAPHICS 630. BOX COM COOLER ORIGINAL. EXEMPLOQUE ATENDE: INTEL BX80677I57400. ', 'Para Upgrade nos Microcomputadores da OM ', 5, '104400', 'R$ 5.220,00'),
(75, '12º B Sup', 89344, 0, 'Cód. UASG: 160353 - CMA\r\nPregão no 12/2018 (SRP)\r\nItem: 72 ? REDE INFORMÁTICA ? PEÇA/ACESSÓRIO\r\nPregão Válido até 06 / 12 / 2019\r\nDescrição: PLACA MÃE MICRO ATX LGA 1151 PLACA MÃE MICRO ATX PARA\r\nPROCESSADORES INTEL LGA 1151, COM CHIPSET INTEL H110. SUPORTE A\r\nPROCESSADORES INTEL DE 6a E 7a GERAÇÃO E À TECNOLOGIA INTEL TURBO BOOST\r\n2.0. MEMÓRIA: TECNOLOGIA DE MEMÓRIA DDR4 DUAL CHANNEL, 2X SLOTS DDR4\r\nDIMM 2133, CAPACIDADE MÁXIMA DE MEMÓRIA DO SISTEMA DE 32GB. BIOS: 64MB\r\nAMI UEFI COM SUPORTE A I', 'Para Upgrade nos Microcomputadores da OM ', 5, '41032', 'R$ 2.051,60'),
(76, '12º B Sup', 89350, 52, 'Cód. UASG: 160353 - CMAPregão no 12/2018 (SRP)Item: 123 ? REDE INFORMÁTICA ? PEÇA/ACESSÓRIOPregão Válido até 06 / 12 / 2019Descrição: DISCO RÍGIDO 4TB PARA CFTV - DISCO RÍGIDO ESPECIAL PARAUTILIZAÇÃO EM SISTEMAS DE CFTV, PARA OPERAÇÃO 24H POR DIA 7 DIAS PORSEMANA, COM ESTABILIDADE NA GRAVAÇÃO DE DADOS, VELOCIDADE DE DISCOCONTROLADA, SUPORTANDO ATÉ 64 CÂMERAS, COM DISSIPAÇÃO DE CALOROTIMIZADA, BAIXO CONSUMO DE ENERGIA E NÍVEL DE RUÍDO. CARACTERÍSTICASTÉCNICAS: CAPACIDA', ' Para uso no sistema de segurança da OM. Para a ampliação do sistema de segurança ? CFTV. Instalação de novas câmeras nas áreas do batalhão.', 6, '69000', 'R$ 4.140,00'),
(77, '12º B Sup', 89353, 0, 'Cód. UASG: 160353 - CMA\r\nPregão no 12/2018 (SRP)\r\nItem: 136 ? REDE INFORMÁTICA ? PEÇA/ACESSÓRIO\r\nPregão Válido até 06 / 12 / 2019\r\nDescrição: FONTE CHAVEADA 12V 10A PARA CFTV - FONTE CHAVEADA 12V 10A, TIPO\r\nCOLMEIA, PARA ALIMENTAÇÃO ELÉTRICA DE SISTEMAS DE CFTV, COM CARCAÇA\r\nMETÁLICA REFORÇADA E PREPARADA PARA DISSIPAÇÃO DE CALOR, COM FÁCIL\r\nINSTALAÇÃO, COM BORNES QUE PERMITEM A CONEXÃO DOS FIOS DAS CÂMERAS\r\nDIRETAMENTE NA FONTE, PODENDO SER FIXADA EM PAREDE OU TRILHO DIN EM RACKS. DEMAIS CARACT', 'Para uso no sistema de segurança da OM. Para a ampliação do sistema de segurança ? CFTV. Instalação de novas câmeras nas áreas\r\ndo batalhão. ', 10, '14950', 'R$ 1.495,00'),
(78, '12º B Sup', 89358, 0, 'Cód. UASG: 160353 - CMA\r\nPregão no 12/2018 (SRP)\r\nItem: 138 ? ESTALIZADOR TENSÃO\r\nPregão Válido até 06 / 12 / 2019\r\n\r\nDescrição: FONTE ESTABILIZADA 12V 1A PARA CFTV - FONTE ESTABILIZADA 12V 1A,\r\n\r\nPARA ALIMENTAÇÃO ELÉTRICA DE CÂMERAS DE SISTEMAS DE CFTV. PRINCIPAIS\r\n\r\nCARACTERÍSTICAS: PROTEÇÃO CONTRA CURTO-CIRCUITO, SOBRECARGA E\r\n\r\nSOBRETENSÃO; FILTRO CONTRA RUÍDOS E INTERFERÊNCIAS NA IMAGEM; FORMATO de IDEAL PARA INSTALAÇÃO EM RÉGUA DE TOMADAS; ENTRADA 100 A 240 VAC AUTOMÁTICO (50/60 HZ); SAÍDA', ' Para uso no sistema de segurança da OM. Para a ampliação do sistema de segurança ? CFTV. Instalação nas áreas novas do câmeras do batalhão.', 50, '4000', 'R$ 2.000,00'),
(79, '12º B Sup', 89372, 0, ' Cód. UASG: 160537 - CMA\r\nPregão no 19/2017 (SRP)\r\nItem: 25 - FERRAMENTAS\r\nPregão Válido até 21 / 08 / 2019\r\nDescrição: KIT FERRAMENTAS MANUTENÇÃO DE COMPUTADORES 13 PEÇAS - KIT DE FERRAMENTAS PARA MANUTENÇÃO DE COMPUTADORES, COMPOSTO DOS SEGUINTES ITENS: 1 ESTOJO COM ZÍPER, 2 PINÇAS, 1 TUBO PLÁSTICO, 1 CHAVE\r\nTESTE, 1 EXTRATOR COM 3 GARRAS, 1 CHAVE TORX T15, 2 CHAVES PHILIPS 1/0MM, 2 CHAVES DE FENDA 3/16 ? - 1/8 ?, 2 CHAVES CANHÃO 3/16 ? - 1/4 ?, 1 ALICATE BICO MEIA- CANA 5 ? COM MOLA.', 'Para uso na instalação de câmeras do sistema de segurança do batalhão. ', 1, '8990', 'R$ 89.90'),
(84, '12º B Sup', 89378, 0, ' Cód. UASG: 160537 - CMA\r\nPregão no 19/2017 (SRP)\r\nItem: 33 ? BATERIA SELADA\r\nPregão Válido até 21 / 08 / 2019\r\nDescrição: BATERIA SELADA, TENSÃO 12 V, AMPERAGEM 7 AH, APLICAÇÃO NO BREAK.', 'Para reposição de bateria interna ', 10, '6675', 'R$ 667.50'),
(85, '12º B Sup', 89381, 0, ' Cód. UASG: 160537 - CMA\r\nPregão no 19/2017 (SRP)\r\nItem: 61 ? CONJUNTO FERRAMENTAS\r\nPregão Válido até 21 / 08 / 2019\r\nDescrição: CONJUNTO FERRAMENTAS, COMPONENTES CHAVE FENDA E PHILIPS/ALICATE BICO CORTE E COMUM/, APLICAÇÃO MANUTENÇÃO EQUIPAMENTOS ELETRÔNICOS', ' Para uso no dia a dia dos trabalhos internos da seção de informática.', 1, '17613', 'R$ 176.13'),
(86, '12º B Sup', 89386, 0, 'Cód. UASG: 160537 - CMA\r\nPregão no 19/2017 (SRP)\r\nItem: 30 - MEMÓRIA PORTÁIL MICROCOMPUTADOR.\r\nPregão Válido até 21 / 08 / 2019\r\nDescrição: MEMÓRIA PORTÁTIL MICROCOMPUTADOR  2 TB  CONEXÃO USB 3.0  ARMAZENAMENTO DE DADOS  HARD DISK EXTERNO. ', ' Para o uso diário de backup de arquivos dos servidores.', 2, '33732', 'R$ 674.64'),
(87, '12º B Sup', 89402, 0, ' Cód. UASG: 160537 - CMA\r\nPregão no 19/2017 (SRP)\r\nItem: 38 ? FILTRO LINHA\r\nPregão Válido até 21 / 08 / 2019\r\nDescrição: FILTRO LINHA, TENSÃO ALIMENTAÇÃO 110/220 V, POTÊNCIA MÁXIMA 1.875 W, CORRENTE MÁXIMA 10 A, QUANTIDADE SAÍDA 8, CARACTERÍSTICAS ADICIONAIS TOMADA ILUMINADA LIGA/DESLIGA, COM PROTEÇÃO VARIA Ç, APLICAÇÃO EQUIPAMENTO INFORMÁTICA/ ELÉTRICO.', ' Para uso na proteçãoelétrica dos equipamentosde informática.', 10, '2881', 'R$ 288.10'),
(88, '12º B Sup', 89406, 0, ' Cód. UASG: 160537 - CMA\r\nPregão no 19/2017 (SRP)\r\nItem: 41 - SOFTWARE\r\nPregão Válido até 21 / 08 / 2019\r\nDescrição: SOFTWARE LICENÇA WINDOWS 10 / 64 BITS.', ' Para uso em máquinas específicas que exija o uso exclusivo do Sistema operacional windows.', 5, '52200', 'R$ 2.610,00'),
(89, '12º B Sup', 89412, 0, 'Cód. UASG: 160537 - CMA\r\nPregão no 19/2017 (SRP)\r\nItem: 70 ? CARTUCHO TONER IMPRESSORA LEXMARK\r\nPregão Válido até 21 /08 / 2019\r\nDescrição: CARTUCHO TONER LEXMARK 504H 50F4H00 | MS310 MS312 MS315 MS410 MS415 MS610 | ORIGINAL MARCA LEXMARK. ', 'Para o suprimento dasimpressoras novas a seremadquiridas.', 20, '19600', 'R$ 3.920,00'),
(90, '12º B Sup', 79380, 0, ' Cód. UASG: 160022 - 21a COMPANHIA DE ENGENHARIA DE CONSTRUÇÃO\r\nPregão no 02/2018 (SRP)\r\nItem: 32 ? INTEL SERVER DBS1200SPSR XEON E3\r\nPregão Válido até 22 / 10 / 19\r\nDescrição:\r\nMarca: INTEL SERVER\r\nFabricante: INTEL\r\nModelo / Versão: INTEL SERVER DBS1200SPSR XEON E3\r\nDescrição Detalhada do Objeto Ofertado: SERVIDOR DE ARMAZENAMENTO DESK®\r\n4 NÚCLEOS X1200R V3 INTEL® XEON E3-1231 V3 3.4 GHZ 8 MB / 8GB DDR4 /\r\n12TB SATA3 / RAID 0, 1, 5, 10 / USB 3.0 / RACK 3U / STORAGE, Conectividade USB,\r\nTipo: U', ' Substituição dos servidores da\r\nSeção de Informática do\r\nBatalhão, tendo em vista que os\r\natuais serviços estão instalados\r\nem Desktops comuns, sem fonte\r\nredundante e etc...', 3, '833900', 'R$ 25.017,00'),
(91, '12º B Sup', 79382, 0, 'Cód. UASG: 160016 - CMA\r\nPregão no 232017 (SRP)\r\nItem: 69 ? SWITCH\r\nPregão Válido até 25 / 06 / 19\r\nDescrição: Descrição: SWITCH Descrição Complementar: Switch HPE 1920S 48 portas.\r\nFUNCIONALIDADES: L2; 48 PORTAS 10/100/1000 PoE+; 4 PORTAS SFP; IPV6 host suport; FULLY MANAGED; QOS: Não; STACKING: Não; Part Number: JL386A ', 'Substituição dos ativos de rede Switch 10/100 que encontam-se obsoletos por Switch 100/1000, objetivando melhorar o tráfego da\r\nrede para implementação do SIGELOG ', 2, '448000', 'R$ 8.960,00'),
(92, '12º B Sup', 79542, 0, 'Cód. UASG: 160537 - CMA\r\nPregão no 19/2017 (SRP)\r\nItem: 35 ? ESTABILIZADOR TENSÃO\r\nPregão Válido até 21 / 08 / 2019\r\nDescrição: ESTABILIZADOR TENSÃO, CAPACIDADE 1400 VA, TENSÃO ALIMENTAÇÃO ENTRADA 110/220 V, CARACTERÍSTICAS ADICIONAIS NOBREAK, AUTONOMIA 40 MIN, TENSÃO SAÍDA 110 V ', 'Para uso na proteção elétrica dos equipamentos de informática. ', 20, '54019', 'R$ 10.803,80'),
(93, '12º B Sup', 70743, 0, ' Cód. UASG: 160353 - CMA\r\nPregão no 12/2018 (SRP)\r\nItem: 110 - SWITCH\r\nPregão Válido até 06 / 12 / 2019\r\nDescrição: SWITCH GERENCIÁVEL 24 PORTAS POE - SWITCH GERENCIÁVEL 24\r\nPORTAS COM TECNOLOGIA POE (POWER OVER ETHERNET), GIGABIT\r\nETHERNET, COM 4 MINI-GBIC COMPARTILHADAS. CARACTERÍSTICAS: COM\r\nTOTAL DE 28 PORTAS, SENDO 24 PORTAS 10/100/1000 COM POE, MAIS 4\r\nPORTAS 10/100/1000 COM CONEXÃO DE FORMATO COMPACTO (MINI GBIC)\r\nQUE PERMITEM A CONECTIVIDADE DE FIBRA; SUPORTE SIMULTÂNEO AOS\r\n\r\nPADRÕES PO', ' Para uso no sistema de segurançada OM. Para a ampliação do sistema de segurança Instalação de novas câmeras nasáreas do batalhão.', 2, '140000', 'R$ 2.800,00'),
(94, '12º B Sup', 89161, 0, 'Cód. UASG: 160537 - CMA\r\nPregão no 19/2017 (SRP)\r\nItem: 46 - MULTÍMETRO\r\nPregão Válido até 21 / 08 / 2019\r\nDescrição: MULTÍMETRO, TENSÃO 1.000V  750V  CORRENTE 10A  RESISTÊNCIA 20 OHM  CARACTERÍSTICAS ADICIONAIS: DISPLAY DIGITAL/CAPACITÂNCIA 4N/TESTE TRANSISTOR TIPO DIGITAL. ', 'Uso nas atividades de manutenção dos equipamentos na seção de informática. ', 1, '12797', 'R$ 127.97'),
(95, '12º B Sup', 89150, 0, 'Cód. UASG: 160353 - CMA\r\nPregão no 12/2018 (SRP)\r\nItem: 197 ? ESTANTE RACK\r\nPregão Válido até 06 / 12 / 2019\r\nDescrição: RACK METÁLICO 8U (PAREDE) - RACK METÁLICO 19 POLEGADAS,\r\nCOM ALTURA 8U E PROFUNDIDADE EXTERNA DE 400MM, ESPECÍFICO PARA\r\nGABINETES RACK DE SERVIDOR OU EQUIPAMENTOS DE INFRASTRUTURA.\r\nESPECIFICAÇÕES: ESTRUTURA FEITA EM AÇO CARBONO PRÉ-ZINCADO COM\r\nESPESSURA 0,80MM; PINTURA EM EPÓXI PÓ PRETO MICROTEXTURIZADO\r\nRAL9011, COM CHAPA TRASEIRA PERFURADA PARA FIXAÇÃO EM PAREDE;\r\nCOM 02 ', 'Para reestruturação da infraestrutura de rede. ', 10, '25000', 'R$ 2.500,00'),
(96, '10º GAC Sl', 91139, 52, 'Descrição: NOBREAK 3000VA - SURTA3000XL ', ' Interligação da Rede e equipamentos das estações de trabalho do 10° Grupo de Artilharia de Campanha de Selva.', 35, '29000', 'R$ 10.150,00'),
(97, '10º GAC Sl', 91002, 52, 'Cód. UASG: 16353 Pregão No 00012/2018(SRP) Item: 195 ? NOBREAK 3000VA Pregão Válido até 11 dezembro 2019 Descrição: NOBREAK 600VA BIVOLT 600VA (300W), bivolt (115/220V) na entrada e 115V na saída - STATION II 600 VA BIV', 'Interligação da Rede e equipamentosdas estações de trabalho do 10° Grupo de Artilharia de Campanha de Selva. ', 2, '710000', 'R$ 14.200,00'),
(98, '10º GAC Sl', 91134, 52, 'Cód. UASG: 16353Pregão No 00012/2018(SRP)Item: 110 ? SWITCH GERENCIAVEL 24 PORTAS POEPregão Válido até 11 dezembro 2019Descrição:SWITCH GERENCIAVEL 24 PORTAS POE - INTELBRAS ', 'Recuperação da rede do 10o Grupo de Artilharia de Campanha de Selva. ', 8, '140000', 'R$ 11.200,00'),
(100, '10º GAC Sl', 91152, 52, 'Cód. UASG: 16353 Pregão No 00012/2018(SRP) Item: 25 ? FERRAMENTA Pregão Válido até 11 dezembro 2019 Descrição: KIT FERRAMENTAS MANUTENÇÃO DE COMPUTADORES 13 PEÇAS - kit de ferramentas para manutenção de computadores, ', 'Manutenção dos computadores do 10° Grupo de Artilharia de Campanha de Selva. ', 1, '8990', 'R$ 89.90'),
(101, '10º GAC Sl', 91157, 52, 'Cód. UASG: 16353Pregão No 00012/2018(SRP)Item: 124 ? DISCO RÍGIDO 8TB PARA CFTVPregão Válido até 11 dezembro 2019Descrição: DISCO RÍGIDO 8TB PARA CFTV - disco rígido especial para utilização em sistemas de CFTV, para operação 24h por dia 7 dias por semana ', 'Será utilizado no servidor do 10° Grupo de Artilharia de Campanha de Selva. ', 1, '144900', 'R$ 1.449,00'),
(102, '21ª Cia E Cnst', 79085, 0, ' Cód. UASG: 160022\r\nPregão no: 00002/2018(SRP)\r\nItem: 30\r\nDescrição: Processador: 8a Geração Intel® CoreTM i7-8550U (1.80 GHz até 4.0 GHz) Sistema operacional: Windows 10\r\nHome Single Language, de 64 bits - em Português (Brasil) Placa de vídeo: AMD RadeonTM 520 2GB GDDR5 Memória\r\nRAM: 8GB DDR4 2400MHz (8GBx1) Disco rígido (HD): 1TB (5400 RPM) Tela: LED HD (1366 x 768) 15.6 polegadas com antirreflexo Teclado alfa-numérico de tamanho normal, em Português (Brasil) ABNT2, . Touchpad preciso multitoq', 'Aquisição de notebook para a base administrativa da 21ª Companhia de Engenharia de Construção. ', 7, '374900', 'R$ 26.243,00'),
(103, '21ª Cia E Cnst', 73088, 0, 'Cód. UASG: 160022\r\nPregão no: 00002/2018(SRP)\r\nItem: 23\r\nDescrição: Nobreak senoidal 3200va (3.2 kva); voltagem 110/220, 8 ou 10 tomadas de saída, novo padrão de tomada brasileiro, indicador luminoso de rede normal, baixa, alta e sobrecarga ts-shara senno 3200 IMPRESSORA LASER ', 'Aquisição de nobreak para a sala de servidores da 21ª Companhia de Engenharia de Construção. ', 2, '204977', 'R$ 4.099,54'),
(104, '21ª Cia E Cnst', 73538, 0, 'Cód. UASG: 160022\r\nPregão no: 00002/2018(SRP)\r\nItem: 04\r\nDescrição: HD EXTERNO DE BOLSO 1000GB ; HD EXTERNO 1TB M3 PORTABLE 3.0 PRETO; USB 3.0 HI: 4.8GB / S (COMPATÍVEL COM USB 2.0 480MB / S);NÃO EXIGE FONTE DE ALIMENTAÇÃO ; BAIXO CONSUMO DE ENERGIA, BAIXO RUÍDO, AUTO\r\nBACKUP COMPONENTES: SOFTWARE PARA BACKUP AGENDADO AUTOMÁTICO E BACKUP DE DADOS NO GERENCIADOR CENTRALMENTE TEMPO SEGURO T: PROTEGE OS DADOS, DEFINIR UMA SENHA AO USAR O AUTO CONECTE O SOFTWARE\r\nDE BACKUP E GO: BASTA LIGAR E TRABAL', ' Utilização para realizar backup de arquivos.', 10, '28700', 'R$ 2.870,00'),
(105, '21ª Cia E Cnst', 73580, 0, 'Cód. UASG: 160022\r\nPregão no: 00002/2018(SRP)\r\nItem: 03\r\nDescrição: Estabilizador tensão/ estabilizador, tensão alimentação entrada 110/220v, tensão alimentação saída 115v, características adicionais proteção contra transientes e surto de tensão /, freqüência 50/60, quantidade tomadas saída 4 ou 5 - padrão nema 5/15. 500va. ', ' Devido constantes quedas de energia no município faz- se necessário utilização de estabilizador de tensão.', 40, '8494', 'R$ 3.397,60'),
(106, '21ª Cia E Cnst', 73607, 0, 'Cód. UASG: 160022\r\nPregão no: 00002/2018(SRP)\r\nItem: 24\r\nDescrição: Estabilizador tensão, capacidade 1400, tensão alimentação entrada 110/220, características adicionais nobreak, autonomia 40 min, tensão saída 110, que possua no mínimo 05 tomadas de saída padrão novo (modelo similar) ts-shara 1200v ', ' Utilização nos computadores da base administrativa da 21a Companhia de Engenharia de Construção', 40, '49987', 'R$ 19.994,8'),
(107, '21ª Cia E Cnst', 73543, 0, 'Cód. UASG: 160022\r\nPregão no: 00002/2018(SRP)\r\nItem: 15\r\nDescrição: PENTE DE MEMÓRIA, CAPACIDADE MEMÓRIA 4GB, TIPO DDR3, FREQUENCIA 1333 MHZ CL9. ', ' Utilização nos computadores da base administrativa da 21ª Companhia de Engenharia de Construção.', 30, '11719', 'R$ 3.515,70'),
(108, '21ª Cia E Cnst', 73852, 0, ' Cód. UASG: 160022Pregão no: 00002/2018(SRP)Item: 66Descrição: Mouse USB. Especificações: Conexão USB 2.0 com fio, Comprimento do cabo: 1,0m,Resolução 1.000dpi, Botões: 3, Cor: preto. Similar: Mouse usb hp x900 preto.', ' Utilização nos computadores da base administrativa da 21ª Companhia de Engenharia de Construção.', 70, '800', 'R$ 560.00'),
(109, '21ª Cia E Cnst', 73585, 0, ' Cód. UASG: 160536\r\nPregão no: 10/2018(SRP)\r\nItem: 05\r\nDescrição: FONTE DE ALIMENTAÇÃO ATX POTÊNCIA 500W, PADRÃO ATX 12V V2.0, TENSÃO 110V/220V, FREQUÊNCIA 50 ~ 60 HZ, COM CERTIFICADO 80 PLUS BRONZE. IGUAL OU SUPERIOR.', 'Utilização nos computadores da base administrativa da 21a Companhia de Engenharia de Construção. ', 50, '19000', 'R$ 9.500,00'),
(110, 'Cmdo Fron Rondônia/6º BIS', 74117, 0, ' Cód. UASG:  160346\r\nPregão nº 00012/2018 (SRP)\r\nItem: 66 ? FONTE ALIMENTAÇÃO ININTERRUPTA\r\nPregão Válido até  10 Jan 2020\r\n\r\nDescrição: NOBREAK Potência Máxima 3.200 VA, tensão de 60 Hz, entrada 115/127/220V', ' Revitalização  do Data Center', 2, '283229', 'R$ 5.664,58'),
(111, 'Cmdo Fron Rondônia/6º BIS', 74240, 0, 'Cód. UASG:  160346\r\nPregão nº 00012/2018 (SRP)\r\nItem: 64 ? FONTE ALIMENTAÇÃO ININTERRUPTA\r\nPregão Válido até  10 Jan 2020\r\n\r\nDescrição: NOBREAK Potência Máxima 1.400 VA, entrada 115/127/220V ', 'Revitalização do Pavilhão Administrativo da OM ', 4, '58258', 'R$ 2.330,32'),
(112, 'Cmdo Fron Rondônia/6º BIS', 74081, 0, 'Cód. UASG:  160346\r\nPregão nº 00012/2018 (SRP)\r\nItem: 61 ? ESTANTE\r\nPregão Válido até  10 Jan 2020\r\n\r\nDescrição: Rack para servidor de 42Us (1,90m de altura x 60cm de largura x 107cm de profundidade) na cor preta ', 'Revitalização  do Data Center ', 1, '573066', 'R$ 5.730,66'),
(113, 'Cmdo Fron Rondônia/6º BIS', 74125, 0, 'Cód. UASG:  160346\r\nPregão nº 00012/2018 (SRP)\r\nItem: 67 ? REDE INFORMÁTICA - PEÇA / ACESSÓRIO\r\nPregão Válido até  10 Jan 2020Revitalização  do Data Center\r\n\r\nDescrição: Cabo FTP blindado  Cat5. Rolo com 333 metros ', ' Revitalização do Pavilhão Administrativo da OM', 1, '96100', 'R$ 961.00'),
(114, 'Cmdo Fron Rondônia/6º BIS', 74110, 0, 'Cód. UASG:  160346\r\nPregão nº 00012/2018 (SRP)\r\nItem: 62 ? SWITCH\r\nPregão Válido até  10 Jan 2020\r\n\r\nDescrição: - Switch gerenciável com 24 portas gigabit rj45 10/100/1000Mbps e 4 slots sfp, largura de banda de 56Gbps, taxa de encaminhamento de pacotes de 41.7 Mbps ', 'Revitalização do Data Center ', 6, '299532', 'R$ 17.971,92'),
(115, 'Cmdo Fron Rondônia/6º BIS', 74245, 0, 'Cód. UASG:  160346\r\nPregão nº 00012/2018 (SRP)\r\nItem: 70 ? ELETROCALHA\r\nPregão Válido até  10 Jan 2020\r\n\r\nEletrocalha perfurada tipo U. Dimensões de 300mmx50mmx3000mm ', 'Revitalização do Pavilhão Administrativo da OM\r\n ', 40, '27466', 'R$ 10.986,40'),
(116, 'Cmdo Fron Solimões/8º BIS', 76314, 0, ' Cód. UASG: 788820\r\nPregão nº 11/2018 (SRP)\r\nItem: 9-Acumulador de Tensão\r\nPregão Válido até 07 marlo 2020\r\n\r\nDescrição: ACUMULADOR TENSÃO Tratamento Diferenciado: Tipo I - Participação Exclusiva de ME/EPP Aplicabilidade Decreto 7174: Não Aplicabilidade Margem de Preferência: Sim - Percentual: 10,0000% (Normal) + 5,0000% (Adicional) Descrição: ACUMULADOR TENSÃO NOBREAK 5000VA OU SUPERIOR, COR PRETA, ENTRADA BIVOLT 115/220V, SAÍDA: 115VCA, COM BORNES PARA CONEXÃO DE BANCO DE BATERIAS, COM MÍNIMO ', 'Proteção dos equipamentos eletroeletrônicos ', 3, '559999', 'R$ 16.799,97'),
(117, 'Cmdo Fron Solimões/8º BIS', 76633, 0, ' Cód. UASG: 160537\r\nPregão nº 19/2017 (SRP)\r\nItem: 20-Placa de rede\r\nPregão Válido até 30 julho 2019\r\n\r\nDescrição: PLACA DE REDE GIGABIT ETHERNET (10/100/1000MBPS) QUE SE CONECTA AO SLOT PCI DO COMPUTADOR. COM SINGLE UTP/STP E SUPORTE A AUTO-NEGOCIAÇÃO (NWAY) SUPORTA 32-BIT 33/66MHZ BUS FONTE TIPO PCI DE GERENCIAMENTO DE ENERGIA CONTÊM DOIS GRANDES FIFOS INDEPENDENTES DE RECEPÇÃO E TRANSMISSÃO UM STP / UTP CONECTO FORNECE LEDS PARA INDICAR LINK REDE.', 'Interligação da Rede e equipamentos das estações de trabalho  ', 10, '4450', 'R$ 445.00'),
(118, 'Cmdo Fron Solimões/8º BIS', 80378, 0, 'Cód. UASG: 160537\r\nPregão nº 19/2017 (SRP) \r\nItem: 35-estabilizador de tensão\r\nPregão Válido até 30 julho 2019\r\n\r\nDescrição: : NOBREAK 1400VA  BIVOLT  AUTOMÁTICO  COM FILTRO DE LINHA  ESTABILIZADOR INTERNO COM 4 ESTÁGIOS DE REGULAÇÃO  FORMA DE ONDA SENOIDAL POR APROXIMAÇÃO (RETANGULAR PWM)  AUTODIAGNÓSTICO DE BATERIA  CONECTOR DO TIPO ENGATE RÁPIDO PARA CONEXÃO DO MÓDULO DE BATERIA 12 VOLTS EXTERNO AO NOBREAK  ANÁLISE DE DISTÚRBIOS DA REDE ELÉTRICA COM ATUAÇÃO PRECISA DO EQUIPAMENTO EM REDES INS', 'Proteção dos equipamentos eletroeletrônicos ', 20, '54019', 'R$ 10.803,80'),
(119, 'Cmdo Fron Solimões/8º BIS', 76511, 0, 'Cód. UASG: 160537\r\nPregão nº 19/2017 (SRP) \r\nItem: 36-Fonte Alimentação\r\nPregão Válido até 30 julho 2019\r\n\r\nDescrição: : FONTE ALIMENTAÇÃO, CARACTERÍSTICAS ADICIONAIS ESTABILIZADA, TENSÃO ALIMENTAÇÃO110/240 VCA, TENSÃO SAÍDA 12 VDC, TIPO CHAVEADA, DIMENSÕES 200 X 100 X 50 MM, APLICAÇÃO MICROCÂMERAS CFTV, CORRENTE NOMINAL 10 A, REFERÊNCIA FABRICANTE VIVATEC, ACESSÓRIOS FONTE AC/DC 12V, POTÊNCIA NOMINAL 120 W, FREQUÊNCIA NOMINAL 50/60 HZ\r\n ', 'Alimentação de equipamentos de informática ', 6, '2730', 'R$ 163.80'),
(120, '17º Pel Com Sl', 85240, 0, 'Cód. UASG:160349\r\nPregão nº 01/2018(SRP)\r\nItem: 53 ? No-break\r\nPregão Válido até 27 JUN 19\r\n\r\nDescrição: No-break com estabilizador microprocessado: com bateria interna, potência nominal de 1400VA ou superior, entrada bivolt e saída de 115v, com tomada para bateria externa auxiliar e no mínimo 05 (cinco) tomadas traseiras.  ', 'Substituição de equipamentos já danificados pelo tempo de uso ', 5, '39687', 'R$ 1.984,35');
INSERT INTO `empenho` (`id`, `sigla`, `seq`, `nd`, `descricao`, `finalidade`, `qtd`, `vl`, `vlt`) VALUES
(121, '17º Pel Com Sl', 85239, 0, 'Cód. UASG:160349\r\nPregão nº 01/2018(SRP)\r\nItem: 60 ? Servidor de rede\r\nPregão Válido até 27 JUN 19\r\n\r\nDescrição: Servidor de rede (2U) Formato Rack de 2 U Processadores Família de produtos E5-2600 do processador IntelXeon Soquetes de processador 2 Interconexão interna Dois links Intel QuickPath Interconnect (QPI): 6,4 GT/s; 7,2 GT/s; 8,0 GT/s Cache 2,5 MB por núcleo; opções de núcleo: 2, 4, 6, 8 Chipset Intel C600, etc ', 'Implantação de serviços informatizados necessários na OM ', 1, '1845400', 'R$ 18.454,00'),
(122, 'CIGS', 75033, 0, 'Cód. UASG: 153163\r\nPregão nº 436_2018 (SRP)\r\nItem: 19 ? SWITCH\r\nPregão Válido até 12/11/2019\r\nDescrição: Switch 24 portas 10/100/1000 - Cisco SF300-24 Modalidade carona: Universidade Federal de Santa Catarina\r\n ', 'Interligação da Rede e equipamentos das estações de trabalho do Centro de Instrução de Guerra na Selva. ', 2, '350000', 'R$ 7.000,00'),
(123, 'CIGS', 75048, 0, 'Cód. UASG: 160344\r\nPregão nº 02_2018 (SRP) \r\nItem: 18 - Nobreaks\r\nPregão Válido até 12/09/2019\r\nDescrição:Nobreak 3.2 KVA, bivolt - TS Shara UPS Professional 3200; Modalidade carona: Exército - Comando 7 Brigada Infant. Motorizada - RN ', 'Substituição dos ativos de Redes dos servidores do Centro de Instrução de Guerra na Selva. ', 5, '172000', 'R$ 8.600,00'),
(124, 'CRO/12', 73026, 0, 'Sistema Operacional - Windows 10 Pro -x32/x64\r\nPREGÃO: 01/2018 (SRP)\r\nUASG: 153161\r\nITEM: 09\r\nDESCRIÇÃO:\r\nConforme Termo de Homologação do Pregão Eletrônico N°00001/2018 (SRP) ', 'Em tempo atuais aonde a facilidade para a denúncia de sofware irregular existe e onde as empresas são acionadas em questões de\r\nsofware irregular é preciso que gestores estejam atentos a questões referentes a regularizar o Windows. Evitando assim:\r\n1) Multas decorrentes de uso indevido;\r\n2) Sistemas operacionais não atualizados:\r\n3) Vunerabilidades de segurança nos ambientes e.\r\n4) Gastos em questões jurídicas. ', 50, '20500', 'R$ 10.250,00'),
(125, 'CRO/12', 73028, 0, ' Microsoft - Office Prof - x32/x64\r\nPREGÃO: 01/2018 (SRP)\r\nUASG: 153161\r\nITEM: 08\r\nDESCRIÇÃO:\r\nConforme Termo de Homologação do Pregão Eletrônico N°00001/2018 (SRP)', 'Em tempo atuais aonde a facilidade para a denúncia de sofware irregular existe e onde as empresas são acionadas em questões de\r\nsofware irregular é preciso que gestores estejam atentos a questões referentes a regularizar o Windows. Evitando assim:\r\n1) Multas decorrentes de uso indevido;\r\n2) Sistemas operacionais não atualizados:\r\n3) Vunerabilidades de segurança nos ambientes e.\r\n4) Gastos em questões jurídicas', 50, '12000', 'R$ 6.000,00'),
(126, 'CRO/12', 73003, 0, ' Switch gerenciavel 48 portas. Cat 6e\r\nPREGÃO: 02/2018 (SRP)\r\nUASG: 153295\r\nITEM: 13\r\nDESCRIÇÃO:\r\nConforme Termo de Homologação do Pregão Eletrônico N°02/2018 (SRP)', 'Interligação da Rede e equipamentos das estações de trabalho da Comissão Regional de Obras/12aRM', 5, '270000', 'R$ 13.500,00'),
(127, 'CRO/12', 73004, 0, 'Patch Panei 48 portas - Cat 6e\r\nPREGÃO: 26/2018 (SRP)\r\nUASG:160016\r\nITEM: 33 \r\nDESCRIÇÃO:\r\nConforme Termo de Homologação do Pregão Eletrônico N° 26/2018 (SRP)', ' Interligação da Rede e equipamentos das estações de trabalho da Comissão Regional de Obras/12aRM', 5, '38000', 'R$ 1.900,00'),
(128, 'CRO/12', 72998, 0, ' Cabo Rede Cat5e - Caixa\r\nPREGÃO: 26/2018 (SRP)\r\nUASG:160016\r\nITEM: 45\r\nDESCRIÇÃO:\r\nConforme Termo de Homologação do Pregão Eletrônico N° 26/2018 (SRP)', 'Interligação da Rede e equipamentos das estações de trabalho da Comissão Regional de Obras/12aRM ', 5, '41000', 'R$ 2.050,00'),
(129, 'CRO/12', 72999, 0, 'Cabo Rede Cat6e-Caixa\r\nPREGÃO: 26/2018 (SRP)\r\nUASG:160016\r\nITEM: 46\r\nDESCRIÇÃO:\r\nConforme Termo de Homologação do Pregão Eletrônico N°26/2018 (SRP) ', 'Interligação da Rede e equipamentos das estações de trabalho da Comissão Regional de Obras/12aRM ', 5, '56200', 'R$ 2.810,00'),
(130, 'CRO/12', 73000, 0, ' Cabo Rede Cat5e - Patch Cord - 2M\r\nPREGÃO: 22/2017 (SRP)\r\nUASG:160016\r\nITEM: 104\r\nDESCRIÇÃO:\r\nConforme Termo de Homologação do Pregão Eletrônico N° 26/2018 (SRP)', ' Interligação da Rede e equipamentos das estações de trabalho da Comissão Regional de Obras/12aRM', 50, '18200', 'R$ 9.100,00'),
(132, 'CRO/12', 74928, 0, 'Cabo Rede Cat5e - Patch Cord - 40CM\r\nPREGÃO: 26/2018 (SRP)\r\nUASG:160016\r\nITEM: 104\r\nDESCRIÇÃO:\r\nConforme Termo de Homologação do Pregão Eletrônico N° 26/2018 (SRP) ', 'Interligação da Rede e equipamentos das estações de trabalho da Comissão Regional de Obras/12aRM', 50, '18200', 'R$ 9.100,00'),
(134, 'CRO/12', 73005, 0, 'Placa de Rede - PCI\r\nPREGÃO: 26/2018 (SRP)\r\nUASG:160016\r\nITEM: 40\r\nDESCRIÇÃO:\r\nConforme Termo de Homologação do Pregão Eletrônico N° 26/2018 (SRP)', 'Interligação da Rede e equipamentos das estações de trabalho da Comissão Regional de Obras/12ª RM', 20, '6500', 'R$ 1.300,00'),
(135, 'CRO/12', 73006, 0, 'Placa de Rede - PCI-e\r\nPREGÃO: 26/2018 (SRP)\r\nUASG:160016\r\nITEM: 40\r\nDESCRIÇÃO:\r\nConforme Termo de Homologação do Pregão Eletrônico N° 26/2018 (SRP)', 'Interligação da Rede e equipamentos das estações de trabalho da Comissão Regional de Obras/12ª RM', 25, '6500', 'R$ 1.625,00'),
(136, 'CRO/12', 73002, 0, 'Conector Fêmea Rj45 Keystone - Cat5e1Cat6e-Pcto 10Und\r\nPREGÃO: 26/2018 (SRP)\r\nUASG:160016\r\nITEM: 49\r\nDESCRIÇÃO:\r\nConforme Termo de Homologação do Pregão Eletrônico N°26/2018 (SRP) ', 'Interligação da Rede e equipamentos das estações de trabalho da Comissão Regional de Obras/12ª RM', 65, '500', 'R$ 325.00'),
(137, '17º Pel Com Sl', 85240, 0, ' Cód. UASG:160349\r\nPregão nº 01/2018(SRP)\r\nItem: 53 ? No-break\r\nPregão Válido até 27 JUN 19\r\n\r\nDescrição: No-break com estabilizador microprocessado: com bateria interna, potência nominal de 1400VA ou superior, entrada bivolt e saída de 115v, com tomada para bateria externa auxiliar e no mínimo 05 (cinco) tomadas traseiras. ', 'Substituição de equipamentos já danificados pelo tempo de uso ', 5, '39687', 'R$ 1.984,35'),
(138, '17º Pel Com Sl', 85239, 0, 'Cód. UASG:160349\r\nPregão nº 01/2018(SRP)\r\nItem: 60 ? Servidor de rede\r\nPregão Válido até 27 JUN 19\r\n\r\nDescrição: Servidor de rede (2U) Formato Rack de 2 U Processadores Família de produtos E5-2600 do processador IntelXeon Soquetes de processador 2 Interconexão interna Dois links Intel QuickPath Interconnect (QPI): 6,4 GT/s; 7,2 GT/s; 8,0 GT/s Cache 2,5 MB por núcleo; opções de núcleo: 2, 4, 6, 8 Chipset Intel C600, etc ', ' Implantação de serviços informatizados necessários na OM', 1, '1845400', 'R$ 18.454,00');

-- --------------------------------------------------------

--
-- Estrutura da tabela `om`
--

CREATE TABLE `om` (
  `id` int(20) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `sigla` varchar(100) NOT NULL,
  `cidade` varchar(50) NOT NULL,
  `telefone` varchar(30) NOT NULL,
  `ritex` varchar(30) NOT NULL,
  `comandante` varchar(70) NOT NULL,
  `guerra` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `om`
--

INSERT INTO `om` (`id`, `nome`, `sigla`, `cidade`, `telefone`, `ritex`, `comandante`, `guerra`) VALUES
(1, 'COMANDO MILITAR DA AMAZÔNIA ', 'CMA', 'Manaus', '(92) 3659-1082', '840-1094', 'César Augusto Nardi de Souza', 'Gen Ex Nardi'),
(2, 'CIA COMANDO CMA', 'CIA CMD CMA', 'Manaus', '(92) 3659-1014', '840-1014', '', ''),
(3, 'CENTRO DE INSTRUÇÃO DE GUERRA NA SELVA', 'CIGS', 'Manaus', '(92) 2125-6405', '840-6405', '', ''),
(4, '4º BATALHÃO DE AVIAÇÃO ', '4º BAvEx', 'Manaus', '(92) 98128-6316', '840-5674', '', ''),
(5, '7º BATALHÃO DE POLÍCIA DO EXÉRCITO', '7º BPE', 'Manaus', '(92) 99133-3814', '', '', ''),
(6, '1º BATALHÃO DE COMUNICAÇÕES DE SELVA', '1º B COM SL', 'Manaus', '(92) 3658-3325', '840-2286', '', ''),
(7, '12º GRUPO DE ARTILHARIA ANTIAÉREA DE SELVA', '12º GAAAe ', 'Manaus', '(92) 98144-4308', '840-1294', '', ''),
(8, '4º CENTRO DE GEOINFIORMAÇÃO ', '4º CGEO', 'Manaus', '(92) 98195-9537', '840-4140', '', ''),
(9, '4º CENTRO DE TELEMATICA DE ARÉA ', '4 CTA', 'Manaus', '(92) 99323-2040', '840-2032', '', ''),
(10, '12º INSPETORIA DE CONTABILIDADE E FINANÇAS DO EXERCITO', '12º ICFEX', 'Manaus', '(92) 3212-5556', '840-4663', '', ''),
(11, 'COMPANHIA DE COMANDO 12º REGIÃO MILITAR', 'CIA CMDO 12º RM', 'Manaus', '(92) 99360-5818', '840-2205', '', ''),
(12, 'PARQUE DE REGIONAL MANUTENÇÃO MILITAR 12', 'PQ R MNT 12', 'Manaus', '(92) 98119-5366', '840-4001', '', ''),
(13, 'COMISSÃO REGIONAL DE OBRAS DA 12 ', 'CRO-12', 'Manaus', '(92)98270-4446', '840-4528', '', ''),
(14, 'CENTRO DE EMBARCAÇÕES DO COMANDO MILITAR', 'CECMA', 'Manaus', '(92)99282-7492', '', '', ''),
(15, 'HOSPITAL MILITAR DA ÁREA DE MANAUS', 'HMAM', 'Manaus', '(92)2126-2032', '840-2005', '', ''),
(16, '2º GRUPAMENTO DE ENGENHARIA', '2 GPT E', 'Manaus', '(92)99481-0102', '840-1041', '', ''),
(17, '1 BATALHÃO DE INFANTARIA DE SELVA (AEROMOVEL)', '1 BIS', 'Manaus', '(92)99523-0692', '', '', ''),
(18, 'CIRCUNSCRIÇÃO DE SERVIÇO MILITAR', '29º CSM', 'Manaus', '(92)3248-2827', '', '', ''),
(19, 'COLÉGIO MILITAR DE MANAUS', 'CMM', 'Manaus', '(92)3659-1000', '', '', ''),
(20, '12º BATALHÃO DE SUPRIMENTO', '12 B SUP', 'Manaus', '(92)4009-2322', '', '', ''),
(21, '4º COMPANHIA DE INTELIGÊNCIA', '4º CIA INTLG', 'Manaus', '(92)981440970', '', '', ''),
(22, '3 COMPANHIA DE FORÇAS ESPECIAIS', '3 CIA DE FE', 'Manaus', '(92)98200-9969', '840-4703', '', ''),
(23, 'comando de fronteira solimões/8 bis', 'CFSOL/8º BIS', 'TABATINGA', '(97)99177-9582', '844-2667', '', ''),
(24, '1º PELOTÃO ESPECIAL DE FRONTEIRA', '1ºPEF', 'PALMEIRA DO JAVARI', '', '845-2627', '', ''),
(25, '2º PELOTÃO ESPECIAL DE FRONTEIRA', '2 PEF', 'IPIRANGA', '', '845-1427', '', ''),
(26, '3º PELOTÃO ESPECIAL DE FRONTEIRA', '3º PEF', 'VILA BITENCOURT', '', '845-1457', '', ''),
(27, '4º PELOTÃO ESPECIAL FRONTEIRA', '4º PEF', 'ESTIRÃO DO EQUADOR', '', '845-1487', '', ''),
(28, '2º BRIGADA DE INFANTARIA DE SELVA', '2º BDA INF SL', 'SÃO GABRIEL DA CACHOEIRA', '(92)98171-9077', '', '', ''),
(29, 'COMPANHIA DE COMANDO DA 2º BRIGADA DE INFANTARIA DE SELVA', 'CIA CMDO 2º BDA', 'SÃO GABRIEL DA CACHOEIRA', '', '', '', ''),
(31, '22º  PELOTÃO DE POLICIA DO EXERCITO', '22º PEL PE', 'SÃO GABRIEL DA CACHOEIRA', '', '', '', ''),
(32, '2º BRIGADA DE INFANTARIA DE SELVA', '2 PEL COM SL', 'SÃO GABRIEL DA CACHOEIRA', '(21)97932-8770', '844-1060', '', ''),
(33, 'HOSPITAL GUARNIÇÃO DE SÃO GABRIEL DA CACHOEIRA', 'HGU', 'SÃO GABRIEL DA CACHOEIRA', '(92)9122-7874', '', '', ''),
(34, '21º COMPANHIA DE ENGENHARIA DE CONSTRUÇÃO', '21º CIA E CNST', 'SÃO GABRIEL DA CACHOEIRA', '(55)8104-9508', '', '', ''),
(35, 'COMANDO DE FRONTEIRA RIO NEGRO E 5 BATALHÃO DE INFANTARIA DE SELVA', 'CFRN/5º BIS', 'SÃO GABRIEL DA CACHOEIRA', '(97)98108-1634', '', '', ''),
(36, '1 PELOTÃO ESPECIAL DE FRONTEIRA', '1 PEF', 'YAURTÊ', '(95)98108-1634', '', '', ''),
(37, '2 PELOTÃO ESPECIAL DE FRONTEIRA', '2 PEF', 'QUERARI', '(95)98108-1634', '', '', ''),
(38, '3 PELOTÃO ESPECIAL DE FRONTEIRA', '3 PEF', 'SÃO JOAQUIM', '(95)98108-1634', '', '', ''),
(39, '4° PELOTÃO ESPECIAL DE FRONTEIRA', '4º PEF', 'CUCUÍ', '(95)98108-1634', '', '', ''),
(40, '5° PELOTÃO ESPECIAL DE FRONTEIRA', '5º PEF', 'MATURACÁ', '(95)98108-1634', '', '', ''),
(41, '6° PELOTÃO ESPECIAL DE FRONTEIRA', '6 PEF', 'PARI-CACHOEIRA', '(95)98108-1634', '', '', ''),
(42, '7° PELOTÃO ESPECIAL DE FRONTEIRA', '7 PEF', 'TUNUÍ', '(95)98108-1634', '', '', ''),
(44, '16º BRIGADA DE INFANTARIA DE SELVA', '16º BDA INF SL', 'TEFÉ', '(92)99157-0282', '', '', ''),
(45, 'COMPANHIA DE COMANDO 16º DA BRIGADA', 'CIA CMDO 16º BDA', 'TEFÉ', '(97)98401-8446', '', '', ''),
(46, '17º BATALHÃO DE INFANTARIA DE SELVA', '17º BIS', 'TEFÉ', '(97)98400-5931', '', '', ''),
(47, '17º BRIGADA DE INFANTARIA DE SELVA', '17 BDA INF SL', 'PORTO VELHO', '(69)99949-9820', '843-2444', '', ''),
(48, 'HOSPITAL DE GUARNIÇÃO PORTO VELHO', 'H GU', 'PORTO VELHO', '(69)98122-9972', '', '', ''),
(49, '54º BATALHÃO DE INFANTARIA DE SELVA', '54º BIS', 'PORTO VELHO', '(92)99377-3544', '', '', ''),
(50, '17º COMPANHIA DE INFANTARIA DE SELVA', '17º CIA INF SL', 'PORTO VELHO', '(69)99329-6638', '', '', ''),
(51, '17º BASE LOGÍSTICA', '17º BA LOG', 'PORTO VELHO', '(69)3216-4700', '', '', ''),
(52, '17º PELOTÃO DE COMUNICAÇÃO', '17º PEL COM', 'PORTO VELHO', '(69)3216-2475', '', '', ''),
(53, '31º CIRCUNSCRIÇÃO DE SERVIÇOS MILITAR', '31º CSM', 'PORTO VELHO', '(69)99248-9783', '', '', ''),
(54, '1º BRIGADA DE INFANTARIA DE SELVA', '1º BDA INF SL', 'BOA VISTA', '(61)99606-2599', '', '', ''),
(56, '12º ESQUADRÃO DE CAVALARIA MECANIZADO', '12º ESQDS C MEC', 'BOA VISTA', '(95)99129-8238', '', '', ''),
(57, '1º PELOTÃO DE COMUNICAÇÕES DE SELVA ', '1º PEL COM SL', 'BOA VISTA', '(21)98129-9399', '', '', ''),
(59, '7º BATALHÃO DE INFANTARIA DE SELVA', '7º BIS', 'BOA VISTA', '(95)98123-5973', '', '', ''),
(60, '10º GRUPA DE ARTILHARIA DE CAMPANHA DE SELVA', '10º GAC SL', 'BOA VISTA', '(95)99159-8943', '', '', ''),
(61, '32º PELOTÃO DE POLICIA DO EXERCITO', '32º PEL PE', 'BOA VISTA', '(51)98334-4156', '', '', ''),
(62, '6º BATALHÃO DE ENGENHARIA DE CONSTRUÇÃO', '6º BEC', 'BOA VISTA', '(95)8110-2357', '', '', ''),
(63, '1º PELOTÃO ESPECIAL DE FRONTEIRA', '1º PEF', 'BONFIM', '(95)99117-2935', '', '', ''),
(64, '2º PELOTÃO ESPECIAL DE FRONTEIRA', '2º PEF', 'NORMANDIA', '(95)99117-2935', '', '', ''),
(65, '3º PELOTÃO ESPECIAL DE FRONTEIRA ', '3º PEF', 'PACARAIMA', '(95)99117-2935', '', '', ''),
(66, '4º PELOTÃO ESPECIAL DE FRONTEIRA', '4º PEF', 'SURUCUCU', '(95)99117-2935', '', '', ''),
(67, '5º PELOTÃO ESPECIAL DE FRONTEIRA', '5º PEF', 'AUARIS', '(95)99117-2935', '', '', ''),
(68, '6º PELOTÃO ESPECIAL DE FRONTEIRA', '6º PEF', 'UIRAMUTÃ', '(95)99117-2935', '', '', ''),
(69, '5° BATALHAO DE ENGENHARIA DE CONSTRUÇÃO', '5º BEC', 'PORTO VELHO', '(69) 3224-3369', '843-840', '', ''),
(70, '6º BATALHÃO DE ENGENHARIA DE CONSTRUÇÃO', '6º BEC', 'BOA VISTA', '(95) 8110-2357', '841-6000', '', ''),
(71, '7º BATALHÃO DE ENGENHARIA DE CONSTRUÇÃO', '7º BEC', 'TEFE', '(68)98100-7946', '', '', ''),
(72, '5° BATALHÃO DE ENGENHARIA DE COMBATE', '5°BEC', 'PORTO VELHO - RO', '(69) 3224-2356', '843-5006', '', ''),
(73, '16ª BASE LOGÍSTICA DE SELVA', '16ªBALOG SL', 'TEFÉ-AM', '(97) 3343-3410', '842-2518', '', '');

-- --------------------------------------------------------

--
-- Estrutura da tabela `operadores`
--

CREATE TABLE `operadores` (
  `id` int(2) NOT NULL,
  `sigla` varchar(50) NOT NULL,
  `nome` varchar(20) NOT NULL,
  `email` varchar(40) NOT NULL,
  `celular` varchar(15) NOT NULL,
  `ritex` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `operadores`
--

INSERT INTO `operadores` (`id`, `sigla`, `nome`, `email`, `celular`, `ritex`) VALUES
(2, '1ª Bda Inf Sl', '3° SGT Tavares', 'sgttavares@1bdainfsl.eb.mil.br', '(95) 3198-2358', '840-2958'),
(5, '7° BPE', '3° SGT DE SOUZA', 'Josimarsouza0618@gmail.com', '(92) 99133-3814', '840 - 2650'),
(6, '12º GAAAe', '2°SGT Gomes Silva ', 'g.sileao.juca@eb.mil.br', '(92) 981444308', '840 - 1294'),
(7, '4º Cia Intlg', 'S Ten De Oliveira', 'deoliveira93@bol.cgmail.comom', '981440370', '840 - 2193'),
(8, '3º Cia FE', '3°SGT ERICK', 'ericksilvacavalcante@gmail.com', '(92)981317907', '840-4773'),
(9, '4° Centro de Geoinformação', '1°Ten Marlon', ' marlon_sg@hotmail.com', '(92) 981959537', '840 - 4140'),
(10, '12º ICFEx', 'Maj Bomfim', 'secinfor12icfex@4cta.eb.mil.br', '(92)3212-9556', '840 - 4663'),
(11, '12ª RM ', '2°Ten Galuço', 'sti@12rm.eb.12rm.eb.mil.br', '(92) 993931804', '840 - 1264'),
(12, 'Cia Cmdo 12ª RM', '1°Sgt Francisco Loyo', 'loyola212r,.eb.mil.br', '(92) 993931804', '840 - 1264'),
(13, 'Pq R Mnt 12', '1°SGT LEITE', 'leite.vale@eb.mil.br', '981195366', '840 - 4001'),
(14, 'CRO/12', 'SC Samuel', 'secinforcro12@4cta.eb.mil.br', '(92)98117-6634', '840 - 4528'),
(15, 'CECMA', '3°sgt Humberto Perei', 'humberto.pereira@eb.eb.mil.br', '(92)99282-7492', ''),
(16, 'HMAM', 'CEL DUARTE', 'chsetinfor@hmam.eb.mil.br', '(92)21262032', ''),
(17, '2º Gpt E', '1° TEN Estéfano ', 'sti@2gpte.eb.mil.br', '(92) 99481-0102', '840-1041'),
(18, '1º BIS', '3°Sgt Simone', 'Simonelima@1bis.eb.mil.br', '(92) 995230692', '840 - 4521'),
(19, 'CFSOL/8º BIS', 'SGT JARMES', 'informatica@8bis.eb.mil.br', '(97) 91779582', '844 - 2667'),
(20, '2ª Bda Inf Sl (São Gabriel da Cachoeira)', '3° Sgt Bruna Coimbra', 'sgtcoimbra@2bdainfsl.eb.mil.br', '(92) 981719077', '34171049'),
(21, '2º Pel Com Sl', '3°SGT Deivison da Si', 'S4_2pelcomsl@2bdainfsl.eb.mil.br', '(21) 979328770', '844-1060'),
(22, 'H gu (São Gabriel da Cachoeira)', '3° Sgt GLAUCO', 'glauco.vieira@eb.mil.br', '(92) 991227874', '840 - 4213'),
(23, 'CFRN/5º BIS', '3° sgt Thianny Rafae', 't.rafaella@gmail.com', '(97) 981081634', '844 -  2543'),
(24, '16ª Bda Inf Sl', '2°Ten Igor', 'igor@16bdainfsl.eb.mil.br', '(92) 991570282', '842 - 2026'),
(25, '17º BIS', '2°SGT Rafael de Oliv', 'rafaeltorres20@hotmail.com', '(97) 984005931', '842 - 2323'),
(26, '7º BEC', '2°Sgt Rui Roketti', 'ruirocketti@gmail.com', '(68)98100-7946', '840-4329'),
(27, '17ª Bda Inf Sl (Rondônia)', '2°Ten Cristiane de S', '', ' (69) 99949-982', '843-2444'),
(28, '54º BIS', '2° Ten Deivid', 'Deivid.eloy@eb.mil.br', '(92)993773544', '844 - 2403'),
(29, '17º Cia Inf sl', '3°Sgt Rodrigo Linhar', 'rolinhares@live.com', '(69) 99329-6638', ''),
(30, '17ª Ba Log', '1°Sgt Agildo', 'agildo76@hotmail.com', '(69) 3216-4700', '840 - 4317'),
(31, '17º Pel Com', '2°Sgt Souza Júnior', 'sgtsouzajr@mail.com', '(69) 99260-0075', '844-843'),
(32, '31ª CSM (Porto Velho)', '3°Sgt Raydeman Sidon', 'raydeman05@gmail.com', '(69) 99248-9783', ''),
(33, '1ª Bda Inf Sl (Boa Vista)', '1°Ten Hernani Ferrei', 'secinforch.bda@1bdainfsl.eb.mil.br', '(61) 996062599', '840-2359'),
(34, '1ª B Log Sl', '3°Sgt William', 'wasilva77@gmail.com', '95 3623 9203', ''),
(35, '12º ESQD C MEC', 'CB Lucas Souza', 'lusousa.silva16@gmail.com', '(95)99129-8238', '840 - 4370'),
(842, 'CITEX', '1° Ten Fabiana', 'FABIANA@CITEX.EB.MIL.BR', '(61) 9995-9540', '860 - 7051'),
(843, '1° PEL Com SI ', '2° Sgt Nunes', 'sgtnunes2008@gmail.com', '(95) 981299399', ''),
(845, '3° BIS', 'Sgt Eliomar', '', '(97) 99178-7241', '844-2102'),
(846, '21° CIA E CNST', 'Servidor Civil  Gust', '', '(97) 3471-1188', '844-3005'),
(847, '4° BIS', '2º Sgt Alison Paulo', '', '(68) 3216- 2904', '840-2904'),
(848, 'CMDO FRON  RONDONIA/6º BIS', '3º Sgt Dias', 'Dias.almeida@eb.mil.br', '(15) 98121-0319', ' 844 - 2825'),
(849, '61º B I S', '3º Sgt Jucá', '', '(68) 9987-8597', '844-2755'),
(850, '5º B E CNST', 'Sgt Goulart', '', '(69) 98101-1172', ' 844 - 2825'),
(851, '2ª Cia Sup (12º B Sup)', '1º Ten Sampaio', '', '', '845 2326'),
(852, '6º B E CNST', '3º Sgt Ribeiro', '', '(95) 98110-2357', ''),
(853, '4º BAVEx', '2º Sgt Alexandre', '', '(92) 98128-6316', '844 - 0000'),
(854, 'H GU TABATINGA', '2º Ten Maia', '', '(92) 98416-5362', '844 - 2745'),
(855, 'BI-02 (CIGS)', '1º Ten David', 'sti@sigs.eb.mil.br', '(92) 99339-4080', '845-6415'),
(856, '1° B COM SL', 'S ten Ericera & 2° S', 's4.4@1bcomsl.eb.mil.br', '(92) 3659-1279', '840-1279'),
(857, '16ª BALOG SL', '2° SGT WELLINGTON', '', '(97) 9145-7708', '842 - 2541'),
(858, '16º Pel Com Sl', 'Sgt Baliero', '', '(97) 9840213', ' 852 - 2253'),
(859, 'H gu  ( Porto Velho)', '1°Ten Leandro Barbos', 'barbosa.lima@hgupv.eb.mil.br', '(69)981229972', '840 - 4825'),
(860, '10º GAC SL', 'Ten Junior / Sgt Rib', '', '(95) 99159-8943', '840 - 4362'),
(861, '32º Pel PE', 'Sgt Santana', '', '(51) 983344156', '841-2262'),
(862, 'CFRR/7º BIS', 'Ten Amaral', 'secinfor.7bis@1bdainfsl.eb.mil.br', '(95) 98123-5973', '849 - 4287');

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `login` varchar(30) NOT NULL,
  `senha` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `empenho`
--
ALTER TABLE `empenho`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `om`
--
ALTER TABLE `om`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `operadores`
--
ALTER TABLE `operadores`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `empenho`
--
ALTER TABLE `empenho`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=139;

--
-- AUTO_INCREMENT for table `om`
--
ALTER TABLE `om`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=74;

--
-- AUTO_INCREMENT for table `operadores`
--
ALTER TABLE `operadores`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=863;

--
-- AUTO_INCREMENT for table `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
